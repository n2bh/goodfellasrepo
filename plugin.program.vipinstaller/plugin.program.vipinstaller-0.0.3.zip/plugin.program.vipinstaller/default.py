################################################################################
#      Copyright (C) 2015 Surfacingx   Modded by FTG                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################



exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("NSAxNSwgYiwgZSwgOSwxYSwxNywxMAo1IGEKCgoKMTkgMWYoKToKCWEuMygpCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgkKYz0wCjE0PTAKMj0wCgoxMToJMj0xOCg4WyIyIl0pCjY6IGQKMTE6CTc9MWMuNCg4WyI3Il0pCjY6IGQKCjFiIDIgMTMgMCAxMiBjIDEzIDAgMTIgMTYoYyk8MTogCgkxZigpCiMjZiMxZSMxZCMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMj")))(lambda a,b:b[int("0x"+a.group(1),16)],"None|1|mode|installerWindow|unquote_plus|import|except|FanArt|params|xbmcplugin|popup|xbmcaddon|url|pass|xbmcgui|F|random|try|or|is|name|xbmc|len|sys|int|def|os|if|urllib|G|T|MainMenu".split("|")))