################################################################################
#      Copyright (C) 2015 Surfacingx   Modded by FTG                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("MTUgMjcsIDExLCAxMCwgNWUsIDNjCjE1IDIzCgo5ICAgICAgID0gJ1s0MyAxNl0gNWEgMjUgWy80M10nCjYyICAgICAgICAgPSAnNTMnCjMzICAgICAgICAgPSAnMTYnCgoxMC4xZC4yZSA9ICcyYy81LjAgKDIyIDViIDYuMSkgMTkvM2EuMzYgKDQ1LCA1MSA0NykgMzAvMzUuMC40Yy41NSAzOS8zYS4zNiA1ZCAyLjY1IDNmIDEuMCcKCjMyIDJhKDM3LCAyNiwgZiA9IDRmKToKCTI5IDNlIGY6CgkJZiA9IDExLjEzKCkKCQlmLjQwKDkgLCJjIDQxIiwnICcsICcgJykKCWYuMTQoMCkKCTQ9M2MuM2MoKQoJMTAuMTgoMzcsIDI2LCAzYiA0YSwgNTIsIDRiOiAxMig0YSwgNTIsIDRiLCBmLCA0KSkKCjMyIDEyKDYzLCAzLCA3LCBmLCA0KToKCTU2OiAKCQlkID0gNTkoNjMgKiAzICogMjQgLyA3LCAyNCkgCgkJNjQgPSAxYSg2MykgKiAzIC8gKGEgKiBhKSAKCQk1ZiA9IDYzICogMyAvICgzYy4zYygpIC0gNCkgCgkJMjkgNWYgPiAwIDU0IDNlIGQgPT0gMjQ6IAoJCQkyMCA9ICg3IC0gNjMgKiAzKSAvIDVmIAoJCTRlOiAKCQkJMjAgPSAwCgkJNWYgPSA1ZiAvIGEgCgkJOCA9ICc2MScKCQkyOSA1ZiA+PSBhOgoJCQk1ZiA9IDVmIC8gYSAKCQkJOCA9ICczZCcKCQkxYyA9IDFhKDcpIC8gKGEgKiBhKSAKCQkzNCA9ICdbNDMgJTE3XVtiXTQ5OlsvYl0gWzQzICUxN10lLjJmWy80M10gM2QgNWMgWzQzICUxN10lLjJmWy80M10gM2RbLzQzXScgJSAoMzMsIDYyLCA2NCwgNjIsIDFjKSAKCQllICAgPSAnWzQzICUxN11bYl00ODpbL2JdIFs0MyAlMTddJS4yZiBbLzQzXSUxNy8xNyAnICUgKDMzLCA2MiwgNWYsIDgpCgkJZSAgKz0gJ1tiXTU4OlsvYl0gWzQzICcrNjIrJ10lMmQ6JTJkWy80M11bLzQzXScgJSA0MigyMCwgNjApCgkJZi4xNChkLCAnJywgMzQsIGUpCgk1MCAxZSwgZToKCQkyMy41NygiNDYgYzogJTE3IiAlIDMxKGUpLCAyNy4yYikKCQkzOCAzMShlKQoJMjkgZi4xYigpOiAKCQlmLjQ0KCkKCQkyMy4yMSgiWzQzICUxN10lMTdbLzQzXSIgJSAoNjIsIDkpLCAiWzQzICUxN10yOCAxZlsvNDNdIiAlIDMzKQoJCTVlLjRkKCk=")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|blocksize|start_time|5|6|filesize|type_speed|ADDONTITLE|1024|B|Downloading|percent|e|dp|urllib|xbmcgui|_pbhook|DialogProgress|update|import|yellow|s|urlretrieve|AppleWebKit|float|iscanceled|total|URLopener|Exception|Cancelled|eta|LogNotify|Windows|wiz|100|Installer|dest|xbmc|Download|if|download|LOGERROR|Mozilla|02d|version|02f|Chrome|str|def|COLOR2|mbs|35|36|url|return|Safari|537|lambda|time|MB|not|MetaSr|create|Content|divmod|COLOR|close|KHTML|ERROR|Gecko|Speed|Size|nb|fs|1916|exit|else|None|except|like|bs|blue|and|153|try|log|ETA|min|VIP|NT|of|SE|sys|kbps_speed|60|KB|COLOR1|numblocks|currently_downloaded|X".split("|")))