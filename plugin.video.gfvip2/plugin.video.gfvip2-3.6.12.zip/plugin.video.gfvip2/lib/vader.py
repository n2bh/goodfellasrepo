import xbmc
import requests
import utils
import matchcenter
import plugintools
import simplejson as json
import xml.etree.ElementTree as ElementTree
import base64
import service
import os
from unidecode import unidecode
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
LOGPATH  = xbmc.translatePath('special://logpath')
LOGFILE  = os.path.join(LOGPATH, 'kodi.log')


jsonExecuteAddon = '{"jsonrpc":"2.0", "method":"Addons.ExecuteAddon", "params": { "wait": false, "addonid": "script.speedtestnet"}, "id":1}'



if sys.version_info >= (2,7):
    from collections import OrderedDict as _ordereddict
else:
    from ordereddict import OrderedDict as _ordereddict

class vader:
    def __init__(self, plugin):
        self.mcc = matchcenter.matchcenter(plugin)
        self.username = plugintools.get_setting('username')
        self.password = plugintools.get_setting('password')
        self.base_url = 'http://vaders.tv/player_api.php?username={username}&password={password}'.format(username=self.username, password=self.password)
        self.session = requests.session()
        self.user_info = None
        self.show_categories = plugintools.get_setting('show_categories')
        self.filter_category_list_name = ['Live Sports']
        self.filter_category_list_id = [26, 35]

        self.epgMap = None
        self.authorise()


    def send_log(self):

        logfilePath = LOGFILE

        if '.spmc'  in logfilePath:
            logfilePath = logfilePath.replace('kodi.log', 'spmc.log')

        file = open(logfilePath, 'r').read()
        data = {'logfile' : file, 'username' : self.username}
        url = 'http://vaders.tv/submitLog'
        self.session.post(url, data=data)


    def get_epg_chan(self, chanName):
        if chanName in self.epgMap:
            val = self.epgMap[chanName]
            if val:
                val = val.decode('utf-8','ignore').encode("utf-8")

            return val
        else:
            return None


    def show_tools(self):
        d = utils.xbmcDialogSelect()
        d.addItem('speedtest', 'Speed Test')
        d.addItem('sendlog', 'Send Logs')

        selection = d.getResult()
        if selection == 'speedtest' :
            # xbmc.executebuiltin("RunPlugin(plugin://script.speedtestnet/)")

            xbmc.executeJSONRPC(jsonExecuteAddon)

        if selection == 'sendlog':
            self.send_log()


    def get_epg_info(self):
        self.epgMap = {}
        url = 'http://vaders.tv/enigma2.php?username={username}&password={password}&type=get_live_streams&cat_id=0'.format(username=self.username, password=self.password)
        response = self.session.get(url).text

        tree = ElementTree.fromstring(response)
        # rootElem = tree.getroot()
        for channel in tree.findall("channel"):
            chanName = base64.b64decode(channel.find("title").text).split('[')[0].strip()
            description = channel.find("description").text
            if description:
                description = base64.b64decode(description).split('(')[0].strip().split(':')[1]
                description = description[3:].strip()
            else:
                description = None
            self.epgMap[chanName] = description

    def _fetch(self, action):
        url = self.base_url + '&action={action}'.format(action=action)
        plugintools.log(url)
        response = self.session.get(url).text
        ordered_reponse = json.loads(response, object_pairs_hook=_ordereddict)
        return ordered_reponse


    def build_stream_url(self, stream):
        chanUrl = 'http://vaders.tv/live/%s/%s/%s.%s' % (self.username, self.password, stream, 'ts')
        return chanUrl

    def authorise(self):
        self.user_info = self.session.get(self.base_url).json()
        if self.user_info['user_info']['auth'] == 1 and self.user_info['user_info']['status'] == 'Active':
            return True
        else:
            return False



    def get_all_streams(self):
        if self.epgMap == None:
            self.get_epg_info()

        action = 'get_live_streams'
        json = self._fetch(action)
        return json


    def get_category_id_live(self, category):
        if self.epgMap == None:
            self.get_epg_info()

        action = 'get_live_streams&category_id={category}'.format(category=category)
        json = self._fetch(action)
        return json

    def get_categories(self):
        action = 'get_live_categories'
        json = self._fetch(action)

        categories = []
        for cat_id in json:
            cat = {}
            category_name = json[cat_id]['category_name']
            cat[cat_id] =   category_name
            categories.append(cat)

        return categories