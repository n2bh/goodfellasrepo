import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
__addon__ = xbmcaddon.Addon()
__author__ = __addon__.getAddonInfo('author')
__scriptid__ = __addon__.getAddonInfo('id')
__addon_id__ = __scriptid__


def check_data_dir():
    if(not xbmcvfs.exists(xbmc.translatePath(data_dir()))):
        xbmcvfs.mkdir(xbmc.translatePath(data_dir()))

def data_dir():
    return __addon__.getAddonInfo('profile')

def addon_dir():
    return __addon__.getAddonInfo('path')

def log(message,loglevel=xbmc.LOGNOTICE):
    xbmc.log(encode(__addon_id__ + "-" + __addon__.getAddonInfo('version') + " : " + message),level=loglevel)

def showNotification(title,message):
    xbmcgui.Dialog().notification(encode(getString(30000)),encode(message),time=4000,icon=xbmc.translatePath(__addon__.getAddonInfo('path') + "/icon.png"),sound=False)

def setSetting(name,value):
    __addon__.setSetting(name,value)

def getSetting(name):
    return __addon__.getSetting(name)

def refreshAddon():
    log("Updated addon")
    global __addon__
    old_addon = __addon__
    __addon__ = xbmcaddon.Addon()
    return old_addon

def getString(string_id):
    return __addon__.getLocalizedString(string_id)

def encode(string):
    return string.encode('UTF-8','replace')



class xbmcDialogSelect:
    def __init__(self,heading='Options'):
        self.heading = heading
        self.items = []

    def addItem(self,ID,display):
        self.items.append((ID,display))

    def getResult(self):
        IDs = [i[0] for i in self.items]
        displays = [i[1] for i in self.items]
        idx = xbmcgui.Dialog().select(self.heading,displays)
        if idx < 0: return None
        return IDs[idx]


def ERROR(txt='',hide_tb=False,notify=False):
    if isinstance (txt,str): txt = txt.decode("utf-8")
    short = str(sys.exc_info()[1])
    if hide_tb:
        LOG('ERROR: {0} - {1}'.format(txt,short))
        return short
    print "_________________________________________________________________________________"
    LOG('ERROR: ' + txt)
    import traceback
    tb = traceback.format_exc()
    for l in tb.splitlines(): print '    ' + l
    print "_________________________________________________________________________________"
    print "`"
    if notify: showNotification('ERROR: {0}'.format(short))
    return short

def LOG(message):
    message = '{0}: {1}'.format(__addon_id__,message)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGNOTICE)

