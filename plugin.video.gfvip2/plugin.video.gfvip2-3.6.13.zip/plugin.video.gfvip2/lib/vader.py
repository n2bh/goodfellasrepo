import xbmc
import requests
import utils
import matchcenter
import plugintools
import simplejson as json
import xml.etree.ElementTree as ElementTree
import base64
import os
import xbmcaddon
import urllib
from shutil import copyfile
from os import listdir
from os.path import isfile, join
import datetime
import time


from unidecode import unidecode
import sys

reload(sys)
sys.setdefaultencoding("utf-8")
LOGPATH  = xbmc.translatePath('special://logpath')
DATABASEPATH = xbmc.translatePath('special://database')
USERDATAPATH = xbmc.translatePath('special://userdata')

LOGFILE  = os.path.join(LOGPATH, 'kodi.log')


jsonExecuteAddon = '{"jsonrpc":"2.0", "method":"Addons.ExecuteAddon", "params": { "wait": false, "addonid": "script.speedtestnet"}, "id":1}'
jsonNotify = '{"jsonrpc":"2.0", "method":"GUI.ShowNotification", "params":{"title":"PVR", "message":"%s","image":""}, "id":1}'
jsonGetPVR = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"pvrmanager.enabled"}, "id":1}'
jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":%s},"id":1}'


if sys.version_info >= (2,7):
    from collections import OrderedDict as _ordereddict
else:
    from ordereddict import OrderedDict as _ordereddict

class vader:
    def __init__(self, plugin):
        self.mcc = matchcenter.matchcenter(plugin)
        self.username = plugintools.get_setting('username')
        self.password = plugintools.get_setting('password')
        self.enable_pvr = utils.getSetting("enable_pvr")
        self.enableAddons()

        try:
            self.VADER_addon = xbmcaddon.Addon('plugin.video.gfvip2')
            utils.setSetting("pluginmissing", "false")
        except:
            utils.log("Failed to find Vip2 addon")
            self.VADER_addon = None
            utils.setSetting("pluginmissing", "true")
            pass
        try:
            self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
            utils.log("Failed to find pvr.iptvsimple addon")
            self.pvriptvsimple_addon = None
            pass


        self.base_url = 'http://vaders.tv/player_api.php?username={username}&password={password}'.format(username=self.username, password=self.password)
        self.session = requests.session()
        self.user_info = None
        self.show_categories = plugintools.get_setting('show_categories')
        self.filter_category_list_name = ['Live Sports', 'MatchCenter']
        self.filter_category_list_id = [26, 35]
        self.addonNeedsRestart = False

        self.epgMap = None
        self.authorise()




    def send_log(self):

        logfilePath = LOGFILE

        if '.spmc'  in logfilePath:
            logfilePath = logfilePath.replace('kodi.log', 'spmc.log')

        file = open(logfilePath, 'r').read()
        data = {'logfile' : file, 'username' : self.username}
        url = 'http://vaders.tv/submitLog'
        self.session.post(url, data=data)

    def get_epg_chan(self, chanName):
        if chanName in self.epgMap:
            val = self.epgMap[chanName]
            if val:
                val = val.decode('utf-8','ignore').encode("utf-8")

            return val
        else:
            return None

    def show_tools(self):
        d = utils.xbmcDialogSelect()
        d.addItem('speedtest', 'Speed Test')
        d.addItem('sendlog', 'Send Logs')
        d.addItem('advsetting', 'Install Advanced Settings')
        d.addItem('keyboard', 'Install Keybard Settings')


        selection = d.getResult()
        if selection == 'speedtest' :
            # xbmc.executebuiltin("RunPlugin(plugin://script.speedtestnet/)")

            xbmc.executeJSONRPC(jsonExecuteAddon)

        if selection == 'sendlog':
            self.send_log()

        if selection == 'advsetting':
            self.send_log()

        if selection == 'keyboard':
            self.send_log()



    def installKeyboardFile(self):
      keyboard_file_path = os.path.join(xbmc.translatePath('special://home'), 'addons/plugin.video.gfvip2/keyboard.xml')
      if os.path.isfile(keyboard_file_path):
        utils.log("Keyboard file found.  Copying...")
        copyfile(keyboard_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'keymaps/keyboard.xml'))


    def installAdvSettings(self):
        adv_file_path = os.path.join(xbmc.translatePath('special://home'),
                                          'addons/plugin.video.gfvip2/advancedsettings.xml')
        if os.path.isfile(adv_file_path):
            utils.log("Advanced Settings file found.  Copying...")
            copyfile(adv_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'advancedsettings.xml'))



    def get_epg_info(self):
        self.epgMap = {}
        url = 'http://vaders.tv/enigma2.php?username={username}&password={password}&type=get_live_streams&cat_id=0'.format(username=self.username, password=self.password)
        response = self.session.get(url).text

        tree = ElementTree.fromstring(response)
        # rootElem = tree.getroot()
        for channel in tree.findall("channel"):
            chanName = base64.b64decode(channel.find("title").text).split('[')[0].strip()
            description = channel.find("description").text
            if description:
                description = base64.b64decode(description).split('(')[0].strip().split(':')[1]
                description = description[3:].strip()
            else:
                description = None
            self.epgMap[chanName] = description

    def _fetch(self, action):
        url = self.base_url + '&action={action}'.format(action=action)
        plugintools.log(url)
        response = self.session.get(url).text
        ordered_reponse = json.loads(response, object_pairs_hook=_ordereddict)
        return ordered_reponse

    def build_stream_url(self, stream):
        chanUrl = 'http://vaders.tv/live/%s/%s/%s.%s' % (self.username, self.password, stream, 'ts')
        return chanUrl

    def authorise(self):

        self.user_info = self.session.get(self.base_url).json()
        if self.user_info['user_info']['auth'] == 1:
            if self.user_info['user_info']['status'] == 'Active':
                if self.enable_pvr:
                    plugintools.log('updating pvr settings')
                    self.updatePVRSettings()
                    if self.addonNeedsRestart == True:
                        self.restartAddon()

            return self.user_info['user_info']['status']

        else:
            return 'Wrong user/pass'

    def get_all_streams(self):
        if self.epgMap == None:
            self.get_epg_info()

        action = 'get_live_streams'
        json = self._fetch(action)
        return json

    def get_category_id_live(self, category):
        if self.epgMap == None:
            self.get_epg_info()

        action = 'get_live_streams&category_id={category}'.format(category=category)
        json = self._fetch(action)
        return json

    def get_categories(self):
        action = 'get_live_categories'
        json = self._fetch(action)

        categories = []
        for cat_id in json:
            cat = {}
            category_name = json[cat_id]['category_name']
            cat[cat_id] =   category_name
            categories.append(cat)

        return categories

    def enableAddons(self):
        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
        result = xbmc.executeJSONRPC(json)

        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
        result = xbmc.executeJSONRPC(json)

        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None

    def restartAddon(self):
        utils.log("restarting addon")

        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":false},"id":1}'
        result = xbmc.executeJSONRPC(json)
        xbmc.sleep(100)
        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
        result = xbmc.executeJSONRPC(json)

        try:
            self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
            utils.log("Failed to find pvr.iptvsimple addon")
            self.pvriptvsimple_addon = None

    def checkAndUpdatePVRIPTVSetting(self, setting, value):
      if self.pvriptvsimple_addon.getSetting(setting) != value:
        self.pvriptvsimple_addon.setSetting(setting, value)
        self.addonNeedsRestart = True

    def updatePVRSettings(self):

        advFile = os.path.join(xbmc.translatePath('special://userdata'), 'advancedsettings.xml')

        if os.path.exists(advFile) == False:
            self.installAdvSettings()

        groups = []
        # for group in ['Live Sports', 'MatchCenter', 'UKTV HD', 'USTV HD', 'CANTV HD', 'Sportsworld HD',
        #               'Premium Movies', 'South Asian', 'FrenchTV UHD', 'EspanaTV UHD']:

        for group in ['Live Sports', 'MatchCenter', 'UKTV HD', 'USTV HD', 'CANTV HD',
                      'Sportsworld HD', 'Premium Movies', 'South Asian']:

            if plugintools.get_setting(group) == False:
                groups.append(group)

        sort_alpha = plugintools.get_setting('sort_alpha')
        filterString = None
        if len(groups) >0:
            filterString =  ",".join(groups )
            filterString = urllib.quote_plus(filterString)

        if filterString:
            m3uPath = 'http://api.vaders.tv/vget?username={username}&password={password}&filterCategory={filter}'.format(filter=filterString, username=self.username, password=self.password)
        else:
            m3uPath = 'http://api.vaders.tv/vget?username={username}&password={password}'.format(username=self.username,
                                                                                             password=self.password)

        if sort_alpha:
            m3uPath = m3uPath + '&sort=alpha'
        plugintools.log(m3uPath)

        # epgPath = 'http://vaders.tv/xmltv.php?username={username}&password={password}'.format(username=self.username, password=self.password)
        epgPath = 'http://vaders.tv/p2.xml.gz'

        offset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
        offset = offset / 60 / 60 * -1

        self.checkAndUpdatePVRIPTVSetting("epgCache", "false")
        self.checkAndUpdatePVRIPTVSetting("epgPathType", "0")
        self.checkAndUpdatePVRIPTVSetting("epgPath", epgPath)
        self.checkAndUpdatePVRIPTVSetting("m3uPathType", "1")
        self.checkAndUpdatePVRIPTVSetting('epgTimeShift', str(offset))
        self.checkAndUpdatePVRIPTVSetting('epgTSOverride', 'true')
        self.checkAndUpdatePVRIPTVSetting('logoFromEpg', '2')
        self.checkAndUpdatePVRIPTVSetting("m3uUrl", m3uPath)
        self.checkAndUpdatePVRIPTVSetting("m3uPath", '')
        self.checkAndUpdatePVRIPTVSetting("m3uCache", 'true')


        if self.addonNeedsRestart:
            self.restartAddon()
            PVR = json.loads(xbmc.executeJSONRPC(jsonGetPVR))['result']['value']
            xbmc.executeJSONRPC(jsonSetPVR % "true")
            xbmc.executeJSONRPC(jsonNotify % "Live TV Enabled, Restart Kodi")
            utils.log("restarting pvr complete")
            onlyfiles = [f for f in listdir(DATABASEPATH) if isfile(join(DATABASEPATH, f))]
            for file in onlyfiles:
                if 'epg' in file.lower():
                    utils.log('removing '+file)
                    os.remove(os.path.join(DATABASEPATH, file))
                if 'tv' in file.lower():
                    utils.log('removing '+file)
                    os.remove(os.path.join(DATABASEPATH, file))


