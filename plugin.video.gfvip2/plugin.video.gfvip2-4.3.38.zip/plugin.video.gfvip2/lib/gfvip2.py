import xbmc
import requests
import utils
import matchcenter
import plugintools
import simplejson as json
import xml.etree.ElementTree as ElementTree
import base64
import os
import xbmcaddon
import urllib
from shutil import copyfile
from os import listdir
from os.path import isfile, join
import datetime
import time
import copy
import shutil
import re


from unidecode import unidecode
import sys
import xbmcgui
import traceback
import base64



reload(sys)
sys.setdefaultencoding("utf-8")
LOGPATH  = xbmc.translatePath('special://logpath')
DATABASEPATH = xbmc.translatePath('special://database')
USERDATAPATH = xbmc.translatePath('special://userdata')
ADDONDATA = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.gfvip2')
PVRADDONDATA = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/pvr.iptvsimple')
THUMBPATH = xbmc.translatePath('special://thumbnails')
ADDONLIBPATH = os.path.join(xbmcaddon.Addon('plugin.video.gfvip2').getAddonInfo('path'), 'lib')
ADDONPATH = xbmcaddon.Addon('plugin.video.gfvip2').getAddonInfo('path')

sys.path.append(ADDONLIBPATH)



from xml.etree.ElementTree import fromstring, ElementTree, Element, tostring, SubElement

LOGFILE  = os.path.join(LOGPATH, 'kodi.log')


jsonExecuteAddon = '{"jsonrpc":"2.0", "method":"Addons.ExecuteAddon", "params": { "wait": false, "addonid": "script.speedtestnet"}, "id":1}'
jsonNotify = '{"jsonrpc":"2.0", "method":"GUI.ShowNotification", "params":{"title":"PVR", "message":"%s","image":""}, "id":1}'
jsonGetPVR = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"pvrmanager.enabled"}, "id":1}'
jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":%s},"id":1}'
jsonUpdateLibrary = '{"jsonrpc":"2.0","method":"VideoLibrary.Scan"}'
jsonUpdateLibraryClean = '{"jsonrpc":"2.0","method":"VideoLibrary.Clean"}'


if sys.version_info >= (2,7):
    from collections import OrderedDict as _ordereddict
else:
    from ordereddict import OrderedDict as _ordereddict

class gfvip2:
    def __init__(self):
        self.mcc = matchcenter.matchcenter()
        self.username = plugintools.get_setting('username')
        self.password = plugintools.get_setting('password')
        self.enable_pvr = plugintools.get_setting("enable_pvr")
        self.mc_timezone_enable = plugintools.get_setting('mc_timezone_enable')
        self.mc_timezone = plugintools.get_setting('mc_timezone')
        self.catchup_length = plugintools.get_setting('catchup_length')
        self.group_by_name = plugintools.get_setting('group_by_name')
        self.prune_epg = ['md cold plasma', 'try total gym', 'best pan ever!',  'more sex, less stress', 'piyo', 'stop smoking now', 'live with wrinkles!', 'diet of 2017',
                          'buy gold, at-cost!',
                          'shark rocket complete', 'new! get cindy', 'no more wrinkles!']

        self.stream_format_setting = plugintools.get_setting('stream_format')
        self.kodi_version = xbmc.getInfoLabel('System.BuildVersion')

        if self.stream_format_setting == '0':
            self.stream_format = 'ts'
        else:
            self.stream_format = 'm3u8'

        self.enableAddons()

        self.servers = {
                    'US EAST': '185.93.1.85',
                   'US West/Far East': '185.152.67.42',
                   'EU': '185.59.222.57'}

        self.serverMap = {
            '0': '0',
            '185.93.1.85': '1',
            '185.152.67.42': '2',
            '185.59.222.57': '3',
        }


        try:
            self.gfvip2_addon = xbmcaddon.Addon('plugin.video.gfvip2')
            utils.setSetting("pluginmissing", "false")
        except:
            utils.log("Failed to find gfvip2 addon")
            self.gfvip2_addon = None
            utils.setSetting("pluginmissing", "true")
            pass
        try:
            self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:

            utils.log("Failed to find pvr.iptvsimple addon")
            utils.setSetting("pvrmissing", "true")
            self.pvriptvsimple_addon = None
            pass


        self.base_url = 'http://vaders.tv/player_api.php?username={username}&password={password}'.format(username=self.username, password=self.password)
        self.session = requests.session()
        self.user_info = None
        self.show_categories = plugintools.get_setting('show_categories')
        self.filter_category_list_name = ['Live Sports', 'MatchCenter']
        self.filter_category_list_id = [26, 35]
        self.addonNeedsRestart = False

        self.epgMap = None
        self.authorise()



    def averageList(self, lst):
        utils.LOG(repr(lst))
        avg_ping = 0
        avg_ping_cnt = 0
        for p in lst:
            try:
                avg_ping += float(p)
                avg_ping_cnt += 1
            except:
                utils.LOG("Couldn't convert %s to float" % repr(p))
        return avg_ping / avg_ping_cnt



    def testServers(self, update_settings=True):

        servers = self.servers

        serverMap = self.serverMap

        import re, subprocess
        res = None
        ping = False
        with utils.xbmcDialogProgress('Testing servers...') as prog:
            i = 0
            for server in servers:
                i = i +1
                if not prog.update( int((100.0/len(servers)) * i), 'Testing servers...', '', server):
                    utils.setSetting("auto_server", False)
                    return
                ping_results = False
                try:
                    if xbmc.getCondVisibility('system.platform.windows'):
                        p = subprocess.Popen(["ping", "-n", "4", servers[server]], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                    else:
                        p = subprocess.Popen(["ping", "-c", "4", servers[server]], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    ping_results = re.compile("time=(.*?)ms").findall(p.communicate()[0])
                except:
                    utils.LOG("Platform doesn't support ping. Disable auto server selection")
                    utils.setSetting("auto_server", False)
                    return None

                if ping_results:
                    utils.LOG("Server %s - %s: n%s" % (i, servers[server], repr(ping_results)))
                    avg_ping = self.averageList(ping_results)
                    if avg_ping != 0:
                        if avg_ping < ping or not ping:
                            res = server
                            ping = avg_ping
                            if update_settings:
                                utils.LOG("Updating settings")
                                utils.setSetting("server", serverMap[servers[res]])

                    else:
                        utils.LOG("Couldn't get ping")

        if res != None:
            xbmcgui.Dialog().ok('Done', 'Server with lowest ping ({0}) setting your server to:'.format(ping), '',
                                res)

            url = 'http://vaders.tv/vapi?username={username}&password={password}&serverIp={serverIp}'.format(
                username=self.username, password=self.password,serverIp=servers[res]
            )

            utils.LOG(url)
            self.session.get(url)
            utils.setSetting("lastSelectedServer", servers[res])

    def send_log(self):

        logfilePath = LOGFILE
        iptv_settings_path = os.path.join(PVRADDONDATA, 'settings.xml')
        gfvip2_settings_path = os.path.join(ADDONDATA, 'settings.xml')
        if '.spmc'  in logfilePath:
            logfilePath = logfilePath.replace('kodi.log', 'spmc.log')

        kodi_logfile = open(logfilePath, 'r').read()
        iptv_settings = open(iptv_settings_path, 'r').read()
        gfvip2_settings = open(gfvip2_settings_path, 'r').read()

        file = kodi_logfile + ' ---- \n' + ' ---- \n' + ' ---- \n'  + iptv_settings + ' ---- \n' + ' ---- \n' + ' ---- \n' + gfvip2_settings
        data = {'logfile' : file, 'username' : self.username}
        url = 'http://vaders.tv/submitLog'
        self.session.post(url, data=data)

    def get_epg_chan(self, chanName):
        if chanName in self.epgMap:
            val = self.epgMap[chanName]
            if val:
                val = val.decode('utf-8','ignore').encode("utf-8")

            return val
        else:
            return None


    def generate_strm_files(self, clean=False):
        vodVersion = float(plugintools.get_setting('vodVersion'))
        if vodVersion < 2:
            utils.log('CLEAN VOD LIBRARY, VERSION INCREASE')
            clean = True
            plugintools.set_setting('vodVersion', '2')
        try:
            strmPath = ADDONDATA
            oldStrmPath = ADDONPATH
            utils.log(strmPath)
            lastAdded = int(plugintools.get_setting('lastAdded'))
            lastUpdated = 0


            streamMap = { 'movies' : 53,
                          'tvshows': 55}


            if clean == True or lastAdded == 0:

                for folder in streamMap:
                    path = os.path.join(oldStrmPath, folder)
                    if os.path.exists(path):
                        shutil.rmtree(path)



                for folder in streamMap:
                    path = os.path.join(strmPath, folder)
                    if os.path.exists(path):
                        shutil.rmtree(path)

                lastAdded = 0



            for folder in streamMap:
                streams = self.get_vod_by_pid(str(streamMap[folder]))
                for stream in streams:
                    name = stream['name']
                    stream_id = stream['stream_id']
                    icon = stream['stream_icon']
                    extension = stream['container_extension']
                    category = stream['category_id']
                    added = stream['added']
                    if added > lastAdded:
                        if added > lastUpdated:
                            lastUpdated = added

                        chanUrl = self.build_stream_url(stream_id, extension=extension, base='movie')

                        if folder == 'tvshows':

                            tv = re.findall('(.*) - S(\d{1,2}) ?E(\d{1,2}) - (.*)', name)
                            if len(tv)>0:
                                # utils.log('using regex')
                                showName = tv[0][0].strip()
                                season =  str(int(tv[0][1]))
                                episode = str(int(tv[0][2]))
                                title = str(tv[0][3])

                            else:
                                season = '0'
                                episode = '0'



                            showName = name.split('-')[0].lstrip().strip()



                            type='tvepisode'
                            strmFilePath = os.path.join(strmPath,folder, showName, name+'.strm')
                            chanData = 'plugin://plugin.video.gfvip2/play/tv/{cat}/{show}/{season}/{episode}'.format(
                                show=name, season=season, episode=episode, cat=category )
                        else:
                            type = 'movie'
                            strmFile = folder +'/' + name +'.strm'
                            strmFilePath = os.path.join(strmPath,strmFile)
                            chanData = 'plugin://plugin.video.gfvip2/play/movie/{cat}/{title}'.format(cat=category, title=name)

                        try:
                            utils.ensure_dir(strmFilePath)
                            with open(strmFilePath, "w") as strmFp:
                                utils.log('creating file {fileName}'.format(fileName=strmFilePath))
                                strmFp.write(chanData)
                        except Exception as e:
                            utils.log("enable to create file \n{0}\n{1}".format(e, traceback.format_exc()))
                            pass

            if lastUpdated != 0:
                plugintools.set_setting('lastAdded', str(lastUpdated))

            utils.showNotification('EPG Updater',
                                   'Updated VOD from gfvip2')

            sourcesPath = USERDATAPATH + '/sources.xml'


            if os.path.exists(sourcesPath):
                write_file = False
                with open(USERDATAPATH + '/sources.xml', 'r') as file:
                    sourcesXML = file.read()
                    root = fromstring(sourcesXML)
                    allNames = root.findall(".//path")
                    utils.log('did sources query')
                    for folder in streamMap:
                        for pathxml in allNames:
                            path = os.path.join(oldStrmPath, folder)

                            if pathxml.text == path:
                                write_file = True
                                utils.log('found old path')
                                pathxml.text = os.path.join(strmPath, folder)

                if write_file == True:
                    with open(USERDATAPATH + '/sources.xml', 'w') as file:
                        file.write(str(tostring(root)))


            else:
                self.addVideoFoldersToSource()

            if os.path.exists(sourcesPath):
                write_file = True
                with open(USERDATAPATH + '/sources.xml', 'r') as file:
                    sourcesXML = file.read()
                    root = fromstring(sourcesXML)
                    allNames = root.findall(".//path")
                    utils.log('did sources query')
                    for folder in streamMap:
                        for pathxml in allNames:
                            path = os.path.join(strmPath, folder)
                            if pathxml.text == path:
                                write_file = False

                if write_file == True:
                    utils.log('adding video folder')
                    self.addVideoFoldersToSource()



                plugintools.set_setting('addedVideoSource', 'true')




            xbmc.executeJSONRPC(jsonUpdateLibrary)
            if clean == True or lastAdded == 0:
                xbmc.executeJSONRPC(jsonUpdateLibraryClean)

        except Exception as e:
            utils.log("Error listing streams \n{0}\n{1}".format(e, traceback.format_exc()))
            pass


    def addVideoFoldersToSource(self):

        strmPath = ADDONDATA
        oldStrmPath = ADDONPATH
        utils.log(strmPath)
        sourcesPath = USERDATAPATH + '/sources.xml'

        streamMap = {'movies': 53,
                     'tvshows': 55}

        if os.path.exists(sourcesPath):
            with open(USERDATAPATH + '/sources.xml', 'r') as file:
                sourcesXML = file.read()
                root = fromstring(sourcesXML)

            for folder in streamMap:
                utils.log('adding video folder source :' + folder)
                video = root.find('video')
                utils.log('found video tag in sources xml')
                source = SubElement(video, 'source')
                name = SubElement(source, 'name')
                name.text = 'gfvip2 ' + folder

                path = SubElement(source, 'path')
                path.text = os.path.join(strmPath, folder)

                sharing = SubElement(source, 'allowsharing')
                sharing.text = 'true'




        else:
            root = Element('sources')
            video = SubElement(root, 'video')

            for folder in streamMap:
                utils.log('adding video folder source :' + folder)
                utils.log('found video tag in sources xml')
                source = SubElement(video, 'source')
                name = SubElement(source, 'name')
                name.text = 'gfvip2 ' + folder

                path = SubElement(source, 'path')
                path.text = os.path.join(strmPath, folder)

                sharing = SubElement(source, 'allowsharing')
                sharing.text = 'true'

        with open(USERDATAPATH + '/sources.xml', 'w') as file:
            file.write(str(tostring(root)))
            utils.showNotification('EPG Updater',
                                   'Restart kodi for changes to take affect')

    def show_tools(self):
        d = utils.xbmcDialogSelect()
        d.addItem('speedtest', 'Speed Test')
        d.addItem('sendlog', 'Send Logs')
        d.addItem('advsetting', 'Install Advanced Settings')
        d.addItem('keyboard', 'Install Keybard Settings')
        d.addItem('testservers', 'Auto Detect Best Server')
        d.addItem('generatestrm', 'Sync VOD & Clean Library')
        d.addItem('tool_deletethumbs', '[ADV] Delete Thumbnails')
        d.addItem('tool_delete_epgdb', '[ADV] Delete EPG Databases')
        d.addItem('tool_deletedb', '[ADV] Delete ALL Databases')



        selection = d.getResult()
        if selection == 'speedtest' :
            # xbmc.executebuiltin("RunPlugin(plugin://script.speedtestnet/)")

            xbmc.executeJSONRPC(jsonExecuteAddon)

        if selection == 'sendlog':
            self.send_log()
            utils.showNotification('gfvip2 Tools',
                                   'Log file sent')

        if selection == 'advsetting':
            self.installAdvSettings()
            utils.showNotification('gfvip2 Tools',
                                   'Installed Advanced Settings')


        if selection == 'keyboard':
            self.installKeyboardFile()
            utils.showNotification('gfvip2 Tools',
                                   'Install Keyboard file')


        if selection == 'testservers':
            self.testServers()

        if selection == 'generatestrm':
            plugintools.set_setting('lastAdded', '0')
            self.generate_strm_files(clean=True)

            utils.showNotification('gfvip2 Tools',
                                   'Files generated')

        if selection == 'tool_deletethumbs':
            self.tool_deletethumbs()
            utils.showNotification('gfvip2 Tools',
                                   'Thumbnails deleted - restart kodi')

        if selection == 'tool_deletedb':
            self.tool_deletedb()


            utils.showNotification('gfvip2 Tools',
                                   'Databases deleted - restart kodi')

        if selection == 'tool_delete_epgdb':
            self.tool_delete_epgdb()

            utils.showNotification('gfvip2 Tools',
                                   'Databases deleted - restart kodi')

    def tool_deletethumbs(self):
        utils.log('deleting thumbnails')
        if os.path.exists(THUMBPATH):
            shutil.rmtree(THUMBPATH)



    def tool_delete_epgdb(self):
        utils.log('deleting epg dbs')
        onlyfiles = [f for f in listdir(DATABASEPATH) if isfile(join(DATABASEPATH, f))]
        for file in onlyfiles:
            if 'epg' in file.lower():
                utils.log('removing ' + file)
                os.remove(os.path.join(DATABASEPATH, file))
            if 'tv' in file.lower():
                utils.log('removing ' + file)
                os.remove(os.path.join(DATABASEPATH, file))

            m3ucache = os.path.join(PVRADDONDATA, 'iptv.m3u.cache')
            if os.path.exists(m3ucache):
                os.remove(m3ucache)
                utils.log('removing ' + m3ucache)




    def tool_deletedb(self):
        utils.log('deleting dbs')
        onlyfiles = [f for f in listdir(DATABASEPATH) if isfile(join(DATABASEPATH, f))]
        for file in onlyfiles:
            if 'epg' in file.lower():
                utils.log('removing ' + file)
                os.remove(os.path.join(DATABASEPATH, file))
            if 'tv' in file.lower():
                utils.log('removing ' + file)
                os.remove(os.path.join(DATABASEPATH, file))
            if 'videos' in file.lower():
                utils.log('removing ' + file)
                os.remove(os.path.join(DATABASEPATH, file))

            m3ucache = os.path.join(PVRADDONDATA, 'iptv.m3u.cache')
            if os.path.exists(m3ucache):
                os.remove(m3ucache)




    def installGenresFile(self):

        try:

            origGenreFilePath = os.path.join(xbmc.translatePath('special://home'),
                                         'addons/plugin.video.gfvip2/' + 'genres.xml')

            genreFilePath = os.path.join(xbmc.translatePath(PVRADDONDATA), 'genres.xml')
            utils.log("Copying...Genres file")
            utils.ensure_dir(genreFilePath)
            copyfile(origGenreFilePath, genreFilePath)

        except Exception as e:
            utils.log("Error copying genre file \n{0}\n{1}".format(e, traceback.format_exc()))
            pass

    def installKeyboardFile(self):
      keyboard_file_path = os.path.join(xbmc.translatePath('special://home'), 'addons/plugin.video.gfvip2/keyboard.xml')
      if os.path.isfile(keyboard_file_path):
        utils.log("Keyboard file found.  Copying...")
        copyfile(keyboard_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'keymaps/keyboard.xml'))


    def installAdvSettings(self):

        if '17' in self.kodi_version:
            adv_file = 'advancedsettings17.xml'
        else:
            adv_file = 'advancedsettings.xml'

        adv_file_path = os.path.join(xbmc.translatePath('special://home'),
                                          'addons/plugin.video.gfvip2/' + adv_file)
        if os.path.isfile(adv_file_path):
            utils.log("Advanced Settings file found.  Copying...")
            copyfile(adv_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'advancedsettings.xml'))

    def get_epg_info(self):
        self.epgMap = {}
        url = 'http://vaders.tv/enigma2.php?username={username}&password={password}&type=get_live_streams&cat_id=0'.format(username=self.username, password=self.password)
        response = self.session.get(url).text

        tree = fromstring(response)
        for channel in tree.findall("channel"):
            chanName = base64.b64decode(channel.find("title").text).split('[')[0].strip()
            description = channel.find("description").text
            if description:
                description = base64.b64decode(description).split('(')[0].strip().split(':')[1]
                description = description[3:].strip()
            else:
                description = None
            self.epgMap[chanName] = description

    def _fetch(self, action, od = True):

        try:
            timeNow = time.time()
            url = self.base_url + '&action={action}'.format(action=action)
            utils.log('attempting to fetch ' + url)
            cacheFile  = action
            cachePath = os.path.join(ADDONDATA, cacheFile)
            utils.log(cachePath)
            if os.path.exists(cachePath):
                fileTime = os.path.getmtime(cachePath)
                if timeNow - fileTime > 1800:
                    utils.log('deleting cache for fetch')
                    os.remove(cachePath)

                    plugintools.log('fetch ' + url)
                    readString = self.session.get(url).text
                    with open(cachePath, 'w') as cacheFp:
                        cacheFp.write(readString)

                else:
                    utils.log('using cache...')
                    with open(cachePath, 'r') as cacheFp:
                        readString = cacheFp.read()
                        try:
                            jsonTest = json.loads(readString)
                        except:
                            plugintools.log('getting from gfvip2 api' + url)
                            readString = self.session.get(url).text
                            with open(cachePath, 'w') as cacheFp:
                                cacheFp.write(readString)


            else:
                plugintools.log('getting from gfvip2 api' + url)
                readString = self.session.get(url).text
                with open(cachePath, 'w') as cacheFp:
                    cacheFp.write(readString)

            if od == False:
                return json.loads(readString)
            else:
                response = readString
                ordered_reponse = json.loads(response, object_pairs_hook=_ordereddict)
                return ordered_reponse

        except Exception as e:
            utils.log("Error fetching url \n{0}\n{1}".format(e, traceback.format_exc()))
            pass

    def build_stream_url(self, stream, extension='ts', base='live'):
        if base == 'live':
            extension = self.stream_format
        chanUrl = 'http://vaders.tv/%s/%s/%s/%s.%s' % (base, self.username, self.password, stream, extension)
        return chanUrl

    def authorise(self):

        # utils.log('attempting to authorise')

        self.username = plugintools.get_setting('username')
        self.password = plugintools.get_setting('password')
        self.base_url = 'http://vaders.tv/player_api.php?username={username}&password={password}'.format(username=self.username, password=self.password)

        if self.username == '' or self.username == None:
            plugintools.open_settings_dialog()
            return "Not Logged In"
        self.user_info = self.session.get(self.base_url).json()
        if self.user_info['user_info']['auth'] == 1:
            if self.user_info['user_info']['status'] == 'Active':
                lastSelectedServer = plugintools.get_setting('lastSelectedServer')
                server = plugintools.get_setting('server')

                for ip, id in self.serverMap.items():
                    if id == server:
                        if lastSelectedServer != ip:
                            url = 'http://vaders.tv/vapi?username={username}&password={password}&serverIp={serverIp}'.format(
                                username=self.username, password=self.password, serverIp=ip
                            )

                            utils.LOG(url)
                            self.session.get(url)
                            utils.setSetting("lastSelectedServer", ip)


                if self.enable_pvr == True:
                    plugintools.log('updating pvr settings')
                    self.updatePVRSettings()
                    if self.addonNeedsRestart == True:
                        self.restartAddon()

            return self.user_info['user_info']['status']

        else:
            utils.log(str(self.user_info) + ' : '  + self.username +  ' : ' + self.password)
            if self.username != '' or self.username != 'black' or self.username != 'beastTrial' or self.username != 'beast1':
                self.send_log()
            return 'Wrong user/pass'


    def get_playlink_archive(self, stream_id, playTime, duration='120'):
        url = 'http://vaders.tv/streaming/timeshift.php?username={username}&password={password}&stream={stream_id}&duration={duration}&start={start}'.format(
            username=self.username, password=self.password,stream_id=stream_id, duration=duration, start=playTime)

        utils.log(url)
        response = self.session.get(url, allow_redirects=False)
        if response.status_code == 302:
            archive_url = response.headers['Location']
            utils.log(archive_url)
            return archive_url
        else:
            return ''

    def get_epg_for_stream(self, stream_id):
        action = 'get_simple_data_table&stream_id='+stream_id
        json = self._fetch(action)
        return json

    def get_all_streams(self):
        if self.epgMap == None:
            self.get_epg_info()

        action = 'get_live_streams'
        json = self._fetch(action)
        return json

    def get_vod_by_pid(self, wanted_pid):
        returnList = []
        catMap = {}
        categories = self.get_vod_categories()
        for category in categories:
            catMap[category['category_id']] = category['parent_id']

        action = 'get_vod_streams'
        json = self._fetch(action)

        for streamObj in json:
            name = streamObj['name']
            added = int(streamObj['added'])
            stream_icon = streamObj['stream_icon']
            category_id = streamObj['category_id']
            stream_id = streamObj['stream_id']
            container_extension = streamObj['container_extension']

            parent_id = catMap[streamObj['category_id']]
            addFlag = False

            if parent_id == wanted_pid:
                addFlag = True

            if category_id == wanted_pid:
                addFlag = True


            if addFlag == True:
                returnMap = {}

                returnMap['stream_id'] = stream_id
                returnMap['category_id'] = category_id
                returnMap['stream_icon'] = stream_icon
                returnMap['added'] = int(added)
                returnMap['name'] = name
                returnMap['container_extension'] = container_extension
                returnList.append(returnMap)

        return  returnList

    def get_recent_vod(self, type):

        categories = self.get_vod_categories()

        if type == 'tvshows':
            wanted_pid = '55'

        if type == 'movies':
            wanted_pid = '53'

        returnList = []
        today = datetime.date.today()
        week_ago = today - datetime.timedelta(days=7)
        week_ago = int(time.mktime(week_ago.timetuple()))
        utils.log(str(week_ago))

        action = 'get_vod_streams'
        json = self._fetch(action)

        for stream in json:
            name = json[stream]['name']
            added = int(json[stream]['added'])
            stream_icon = json[stream]['stream_icon']
            category_id = json[stream]['category_id']
            stream_id = json[stream]['stream_id']
            container_extension = json[stream]['container_extension']
            parent_id = categories[category_id]['parent_id']
            addFlag = False

            if parent_id == wanted_pid:
                addFlag = True

            if category_id == wanted_pid:
                addFlag = True


            if (added > week_ago) and (addFlag == True):
                returnMap = {}

                returnMap['stream_id'] = stream_id
                returnMap['category_id'] = category_id
                returnMap['stream_icon'] = stream_icon
                returnMap['added'] = int(added)
                returnMap['name'] = name
                returnMap['container_extension'] = container_extension
                returnList.append(returnMap)

        returnList = sorted(returnList, key=lambda k: k['added'])
        returnList.reverse()

        return returnList

    def get_category_id_vod(self, category, sort=False):
        plugintools.log('entering category vod')
        action = 'get_vod_streams&category_id={category}'.format(category=category)
        json = self._fetch(action)

        if sort:
            returnList = []
            for key in json:
                newDict = copy.deepcopy(key)
                returnList.append(newDict)

            returnList = sorted(returnList, key=lambda k: k['name'])
            return returnList

        return json

    def get_category_id_live(self, category):
        try:
            if self.epgMap == None:
                self.get_epg_info()

            action = 'get_live_streams&category_id={category}'.format(category=category)
            json = self._fetch(action)
            return json

        except Exception as e:
            utils.log("Error listing streams \n{0}\n{1}".format(e, traceback.format_exc()))
            pass

    def get_vod_categories(self, sort=False):
        action = 'get_vod_categories'
        json = self._fetch(action, od=False)
        # utils.log(str(json))
        if sort:
            returnList = []
            for key in json:
                newDict = copy.deepcopy(key)
                returnList.append(newDict)

            returnList = sorted(returnList, key=lambda k: k['category_name'])
            # utils.natural_sort(returnList, key=lambda c: c.tvg_name)

            return returnList


        return json


    def get_categories(self):
        action = 'get_live_categories'
        json = self._fetch(action)

        categories = []
        for cat_id in json:
            cat = {}
            category_name = cat_id['category_name']
            cat[cat_id['category_id']] =   category_name
            categories.append(cat)

        return categories

    def enableAddons(self):
        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
        result = xbmc.executeJSONRPC(json)

        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
        result = xbmc.executeJSONRPC(json)

        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None

    def restartAddon(self):
        utils.log("restarting addon")

        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":false},"id":1}'
        result = xbmc.executeJSONRPC(json)
        xbmc.sleep(100)
        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
        result = xbmc.executeJSONRPC(json)

        try:
            self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
            utils.log("Failed to find pvr.iptvsimple addon")
            self.pvriptvsimple_addon = None

    def checkAndUpdatePVRIPTVSetting(self, setting, value):
      if self.pvriptvsimple_addon.getSetting(setting) != value:
        self.pvriptvsimple_addon.setSetting(setting, value)
        self.addonNeedsRestart = True

    def updatePVRSettings(self):

        advFile = os.path.join(xbmc.translatePath('special://userdata'), 'advancedsettings.xml')
        genreFile = os.path.join(xbmc.translatePath(PVRADDONDATA), 'genres.xml')


        if os.path.exists(advFile) == False:
            self.installAdvSettings()



        if self.pvriptvsimple_addon != None:
            groups = []
            # for group in ['Live Sports', 'MatchCenter', 'UKTV HD', 'USTV HD', 'CANTV HD', 'Sportsworld HD',
            #               'Premium Movies', 'South Asian', 'FrenchTV UHD', 'EspanaTV UHD']:

            for group in ['Live Sports', 'MatchCenter', 'UKTV HD', 'USTV HD', 'CANTV HD',
                          'Sportsworld HD', 'Premium Movies', 'South Asian']:

                if plugintools.get_setting(group) == False:
                    groups.append(group)

            sort_alpha = plugintools.get_setting('sort_alpha')
            filterString = None
            if len(groups) >0:
                filterString =  ",".join(groups )
                filterString = urllib.quote_plus(filterString)

            if filterString:
                m3uPath = 'http://api.vaders.tv/vget?username={username}&password={password}&filterCategory={filter}&format={format}'.format(format=self.stream_format, filter=filterString, username=self.username, password=self.password)
            else:
                m3uPath = 'http://api.vaders.tv/vget?username={username}&password={password}&format={format}'.format(username=self.username,
                                                                                                 password=self.password, format=self.stream_format)

            if sort_alpha:
                m3uPath = m3uPath + '&sort=alpha'

            # epgPath = 'http://vaders.tv/xmltv.php?username={username}&password={password}'.format(username=self.username, password=self.password)
            epgPath = 'http://vaders.tv/p2.xml.gz'

            if self.mc_timezone_enable == False:
                if '16' in self.kodi_version or '15' in self.kodi_version:
                    offset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
                    offset = offset / 60 / 60 * -1
                if '17' in self.kodi_version:
                    offset =  0


            else:
                offset = self.mc_timezone

            self.checkAndUpdatePVRIPTVSetting("epgCache", "false")
            self.checkAndUpdatePVRIPTVSetting("epgPathType", "0")
            self.checkAndUpdatePVRIPTVSetting("epgPath", epgPath)
            self.checkAndUpdatePVRIPTVSetting("m3uPathType", "1")
            self.checkAndUpdatePVRIPTVSetting('epgTimeShift', str(offset))
            self.checkAndUpdatePVRIPTVSetting('epgTSOverride', 'true')
            self.checkAndUpdatePVRIPTVSetting('logoFromEpg', '2')
            self.checkAndUpdatePVRIPTVSetting("m3uUrl", m3uPath)
            self.checkAndUpdatePVRIPTVSetting("m3uPath", '')
            self.checkAndUpdatePVRIPTVSetting("m3uCache", 'true')


            if self.addonNeedsRestart:
                self.restartAddon()
                # PVR = json.loads(xbmc.executeJSONRPC(jsonGetPVR))['result']['value']
                xbmc.executeJSONRPC(jsonSetPVR % "true")
                xbmc.executeJSONRPC(jsonNotify % "Live TV Enabled, Restart Kodi")
                utils.log("restarting pvr complete")
                onlyfiles = [f for f in listdir(DATABASEPATH) if isfile(join(DATABASEPATH, f))]
                for file in onlyfiles:
                    if 'epg' in file.lower():
                        utils.log('removing '+file)
                        os.remove(os.path.join(DATABASEPATH, file))
                    if 'tv' in file.lower():
                        utils.log('removing '+file)
                        os.remove(os.path.join(DATABASEPATH, file))

            if os.path.exists(genreFile) == False:
                self.installGenresFile()

        else:
            if plugintools.get_setting('warning_msg') != True:
                xbmcgui.Dialog().ok('gfvip2 Streams', 'Looks like you are missing some important functions inside Kodi.',
                                    'This can happen when you are using a preinstalled version of Kodi. The Guide functionality will not work until this is done',
                                    'Install Kodi or SPMC from the Play Store or kodi.tv, to fix this')
                plugintools.set_setting('warning_msg', 'true')



