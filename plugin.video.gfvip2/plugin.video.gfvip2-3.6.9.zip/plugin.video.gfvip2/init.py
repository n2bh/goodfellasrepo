﻿import xbmcplugin, xbmcgui, xbmcaddon,  plugintools
import time
from lib import routing
from lib import  vader
from lib import utils
from xbmcplugin import addDirectoryItem, endOfDirectory
from xbmcgui import ListItem
import xbmc
from unidecode import unidecode
from datetime import datetime
import traceback
import plugintools
from os import listdir
from os.path import isfile, join
import re


firstrun = plugintools.get_setting('first')

import sys
reload(sys)
sys.setdefaultencoding("utf-8")


plugin = routing.Plugin()

@plugin.route('/')
def index():

    try:
        authString = vaderClass.authorise()
        if authString == 'Active':
            if vaderClass.show_categories:
                addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_cat, 'all'), ListItem("Live TV"), True)
            else:
                addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_all), ListItem("Live TV"), True)

            addDirectoryItem(plugin.handle, plugin.url_for(tvguide), ListItem("TV Guide"), True)
            addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_cat, '26'), ListItem("Live Sports"), True)
            addDirectoryItem(plugin.handle, plugin.url_for(show_mc), ListItem("MatchCenter"), True)
            addDirectoryItem(plugin.handle, plugin.url_for(show_vod,'all'), ListItem("Video On Demand"), True)

            addDirectoryItem(plugin.handle, plugin.url_for(index), ListItem(""), False)
            addDirectoryItem(plugin.handle, plugin.url_for(accountInfo), ListItem("My Account"), True)
            addDirectoryItem(plugin.handle, plugin.url_for(settings), ListItem("Settings"), True)
            addDirectoryItem(plugin.handle, plugin.url_for(show_tools), ListItem("Tools"), False)


            endOfDirectory(plugin.handle)
        else:
            addDirectoryItem(plugin.handle, plugin.url_for(settings), ListItem("Unable to Login - {auth}".format(auth=authString)), True)
            addDirectoryItem(plugin.handle, plugin.url_for(show_tools),
                             ListItem("Tools - Please send your log file for analysis if you think this was an error"), False)

            addDirectoryItem(plugin.handle, plugin.url_for(settings), ListItem('Click here to configure'), True)

            endOfDirectory(plugin.handle)

    except Exception as e:
        addDirectoryItem(plugin.handle, plugin.url_for(show_tools), ListItem("Tools - Please send your log file for analysis"), False)
        endOfDirectory(plugin.handle)
        plugintools.log("Error getting index \n{0}\n{1}".format(e, traceback.format_exc()))
        pass




@plugin.route('/tools')
def show_tools():
    vaderClass.show_tools()




@plugin.route('/vod/recent/<type>')
def show_vod_recent(type):


    streams = vaderClass.get_recent_vod(type)

    for stream in streams:
        utils.log(str(stream))
        chanName = stream['name']
        stream_id = stream['stream_id']
        icon = stream['stream_icon']
        container_extension = stream['container_extension']

        chanUrl = vaderClass.build_stream_url(stream_id, extension=container_extension, base='movie')


        title = chanName

        title = str(title.encode('utf-8').decode('ascii', 'ignore'))

        plugintools.add_playable(title=title, url=chanUrl,
                                 thumbnail=icon, plot='', isPlayable=True, folder=False)



    endOfDirectory(plugin.handle)




@plugin.route('/vod/movies/<year>')
def show_movies_year(year):
    try:
        if year == 'all':
            validYears = []
            streams = vaderClass.get_vod_by_pid('53')
            for stream in streams:
                name = stream['name']

                match = re.match(r'.*([1-3][0-9]{3})', name)
                if match is not None:
                    # Then it found a match!
                    validYears.append(int(match.group(1)))

            validYears.sort()
            validYears = list(set(validYears))
            validYears.reverse()

            for year in validYears:
                addDirectoryItem(plugin.handle, plugin.url_for(show_movies_year, year=str(year)), ListItem(
                    str(year)), True)


        else:
            streams = vaderClass.get_vod_by_pid('53')
            for stream in streams:
                name = stream['name']
                if str(year) in name:
                    stream_id = stream['stream_id']
                    icon = stream['stream_icon']
                    extension = stream['container_extension']

                    chanUrl = vaderClass.build_stream_url(stream_id, extension=extension, base='movie')

                    title = name

                    title = str(title.encode('utf-8').decode('ascii', 'ignore'))

                    plugintools.add_playable(title=title, url=chanUrl,
                                             thumbnail=icon, plot='', isPlayable=True, folder=False)

        endOfDirectory(plugin.handle)

    except Exception as e:
        utils.log("Error listing streams \n{0}\n{1}".format(e, traceback.format_exc()))
        pass

@plugin.route('/vod/category/<category_id>')
def show_vod(category_id):
    try:

        if category_id == 'all':
            categories = vaderClass.get_vod_categories()
            for category in categories:
                parent_id = str(categories[category]['parent_id'])
                name = str(categories[category]['category_name'])
                cat_id = category
                if parent_id == '0':

                        addDirectoryItem(plugin.handle, plugin.url_for(show_vod, category_id=str(cat_id)), ListItem(name), True)

            addDirectoryItem(plugin.handle, plugin.url_for(show_movies_year, year='all'), ListItem(
                'Movies - By Year'), True)

            addDirectoryItem(plugin.handle, plugin.url_for(show_vod_recent, type='movies'), ListItem(
                'Recently Added - Movies'), True)
            addDirectoryItem(plugin.handle, plugin.url_for(show_vod_recent, type='tvshows'), ListItem(
                'Recently Added - TV Shows'), True)


        else:
                vod_categories = vaderClass.get_vod_categories(sort=True)

                for category in vod_categories:
                    parent_id = category['parent_id']
                    name = category['category_name']
                    cat_id = category['category_id']
                    if parent_id == category_id:
                        addDirectoryItem(plugin.handle, plugin.url_for(show_vod, category_id=str(cat_id)), ListItem(name),
                                         True)


                streams = vaderClass.get_category_id_vod(category_id, sort=True)
                for stream in streams:
                    chanName = stream['name']
                    stream_id = stream['stream_id']
                    icon = stream['stream_icon']
                    extension = stream['container_extension']

                    chanUrl = vaderClass.build_stream_url(stream_id, extension=extension, base='movie')


                    title = chanName

                    title = str(title.encode('utf-8').decode('ascii', 'ignore'))

                    plugintools.add_playable(title=title, url=chanUrl,
                                             thumbnail=icon, plot='', isPlayable=True, folder=False)



        endOfDirectory(plugin.handle)

    except Exception as e:
        utils.log("Error listing streams \n{0}\n{1}".format(e, traceback.format_exc()))
        pass






@plugin.route('/livetv/category/<category_id>')
def show_livetv_cat(category_id):
    if category_id == 'all':
        categories = vaderClass.get_categories()
        for category in categories:
            for cat_id in category:
                if int(cat_id) not in vaderClass.filter_category_list_id:

                    addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_cat, category_id=str(cat_id)), ListItem(category[cat_id]), True)
        endOfDirectory(plugin.handle)
    else:
        try:
            streams = vaderClass.get_category_id_live(category_id)
            for stream in streams:
                chanName = streams[stream]['name']
                stream = streams[stream]['stream_id']
                icon = streams[stream]['stream_icon']
                chanUrl =  vaderClass.build_stream_url(stream)

                if vaderClass.get_epg_chan(chanName):
                    title = '[COLOR orange]' +  unidecode(chanName) + '[/COLOR] - ' + '[I][COLOR cyan]' + unidecode(vaderClass.get_epg_chan(chanName)) +'[/COLOR][/I]'
                else:
                    title = chanName

                title = str(title.encode('utf-8').decode('ascii', 'ignore'))

                plugintools.add_playable(title=title, url=chanUrl,
                                         thumbnail=icon, plot='',  isPlayable=True, folder=False)

            endOfDirectory(plugin.handle)
        except Exception as e:
            plugintools.log("Error listing streams \n{0}\n{1}".format(e,traceback.format_exc()))
            pass



@plugin.route('/livetv/all/')
def show_livetv_all():
    streams = vaderClass.get_all_streams()
    for stream in streams:
        chanName = streams[stream]['name']
        stream = streams[stream]['stream_id']
        icon = streams[stream]['stream_icon']

        chanUrl = vaderClass.build_stream_url(stream)
        category_id = int(streams[stream]['category_id'])
        if category_id not in vaderClass.filter_category_list_id:
            if vaderClass.get_epg_chan(chanName):
                title = '[COLOR orange]' +  chanName + '[/COLOR] - ' + '[I][COLOR cyan]' + vaderClass.get_epg_chan(chanName) +'[/COLOR][/I]'
            else:
                title = chanName

            title = str(title.encode('utf-8').decode('ascii', 'ignore'))
            plugintools.add_playable(title=title, url=chanUrl,
                                     thumbnail=icon, plot='', isPlayable=True, folder=False)

    endOfDirectory(plugin.handle)


@plugin.route('/mc/')
def show_mc():
    closedTime = plugintools.get_setting('mcClosedTime')
    if closedTime == None or closedTime == '':
        plugintools.set_setting('mcClosedTime', '0')
    closedTime = int((plugintools.get_setting('mcClosedTime')))
    timeDiff = time.time() - closedTime
    if time.time() - closedTime > 3:
        endOfDirectory(plugin.handle)
        vaderClass.mcc.run()
    else:

        endOfDirectory(plugin.handle)
        xbmc.executebuiltin('Action(Back)')




@plugin.route('/accountInfo')
def accountInfo():
    status = vaderClass.user_info['user_info']["status"]
    exp_date = vaderClass.user_info['user_info']['exp_date']
    if exp_date:
        exp_date_str =  datetime.fromtimestamp(int(exp_date)).strftime('%d-%m-%Y')
    else:
        exp_date_str = "Never"
    trial_str = vaderClass.user_info['user_info']["is_trial"]

    if trial_str == "0":
        trial_str = "No"
    else:
        trial_str = "Yes"

    max_connections = vaderClass.user_info['user_info']["max_connections"]
    username = vaderClass.user_info['user_info']["username"]

    addDirectoryItem(plugin.handle, plugin.url_for(accountInfo), ListItem("[COLOR orange] User: [/COLOR]" + username), False)
    addDirectoryItem(plugin.handle, plugin.url_for(accountInfo), ListItem("[COLOR orange] Status: [/COLOR]" + status), False)
    addDirectoryItem(plugin.handle, plugin.url_for(accountInfo), ListItem("[COLOR orange] Expires: [/COLOR]" + exp_date_str), False)
    addDirectoryItem(plugin.handle, plugin.url_for(accountInfo), ListItem("[COLOR orange] Trial Account: [/COLOR]" + trial_str), False)
    addDirectoryItem(plugin.handle, plugin.url_for(accountInfo), ListItem("[COLOR orange] Max Devices: [/COLOR]" + max_connections), False)


    endOfDirectory(plugin.handle)


@plugin.route('/tvguide')
def tvguide():
    xbmc.executebuiltin("XBMC.ActivateWindow(tvguide)")


@plugin.route('/settings')
def settings():
    plugintools.open_settings_dialog()

if __name__ == '__main__':
    username = plugintools.get_setting('username')
    if username == '' or username == None:
        plugintools.open_settings_dialog()

    else:

        vaderClass = vader.vader()
        plugin.run()
