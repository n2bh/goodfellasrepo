import xbmcplugin,xbmcaddon
import time
import datetime
import xbmc
import os
import urllib2,json
import zipfile
import lib.utils as utils
from lib.croniter import croniter
from collections import namedtuple
from shutil import copyfile
import traceback
import plugintools
from lib import vader

jsonGetPVR = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"pvrmanager.enabled"}, "id":1}'
jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":%s},"id":1}'
jsonNotify = '{"jsonrpc":"2.0", "method":"GUI.ShowNotification", "params":{"title":"PVR", "message":"%s","image":""}, "id":1}'


__addon__ = xbmcaddon.Addon()
__author__ = __addon__.getAddonInfo('author')
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__ = __addon__.getAddonInfo('path')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString
debug = __addon__.getSetting("debug")
# offset1hr = __addon__.getSetting("offset1hr")

offset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
offset = offset / 60 / 60 * -1


class epgUpdater:
    def __init__(self):
        self.monitor = UpdateMonitor(update_method = self.settingsChanged)
        self.enable_kodi_library = plugintools.get_setting("enable_kodi_library")
        self.next_run = 0


        try:
          self.VADER_addon = xbmcaddon.Addon('plugin.video.gfvip2')
          utils.setSetting("pluginmissing", "false")
          self.vaderClass = vader.vader()
          authString = self.vaderClass.authorise()

        except:
          utils.log("Failed to find gfvip2 addon")
          self.VADER_addon = None
          utils.setSetting("pluginmissing", "true")
        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None



    def run(self):
        utils.log("scheduler enabled, finding next run time")
        self.vaderClass.generate_strm_files()

        self.findNextRun(time.time())
        while(not xbmc.abortRequested):
            # Sleep/wait for abort for 10 seconds
            now = time.time()


            if(self.enable_kodi_library):
              if(self.next_run <= now):
                  self.vaderClass.generate_strm_files()
                  self.findNextRun(now)
              else:
                  self.findNextRun(now)



            xbmc.sleep(500)
        # del self.monitor



    def settingsChanged(self):
        try:

            utils.log("Settings changed - update")
            old_settings = utils.refreshAddon()


            if utils.getSetting("enable_kodi_library") == 'true' and old_settings.getSetting('enable_kodi_library') == 'false':
                self.vaderClass.generate_strm_files()
                self.enable_kodi_library = plugintools.get_setting('enable_kodi_library')



        except Exception as e:
            utils.log("Error updating settings \n{0}\n{1}".format(e, traceback.format_exc()))
            pass

    def parseSchedule(self):
        schedule_type = int(utils.getSetting("schedule_interval"))
        cron_exp = utils.getSetting("cron_schedule")

        hour_of_day = utils.getSetting("schedule_time")
        hour_of_day = int(hour_of_day[0:2])
        if(schedule_type == 0 or schedule_type == 1):
            #every day
            cron_exp = "0 " + str(hour_of_day) + " * * *"
        elif(schedule_type == 2):
            #once a week
            day_of_week = utils.getSetting("day_of_week")
            cron_exp = "0 " + str(hour_of_day) + " * * " + day_of_week
        elif(schedule_type == 3):
            #first day of month
            cron_exp = "0 " + str(hour_of_day) + " 1 * *"

        return cron_exp


    def findNextRun(self,now):
        #find the cron expression and get the next run time
        cron_exp = self.parseSchedule()
        cron_ob = croniter(cron_exp,datetime.datetime.fromtimestamp(now))
        new_run_time = cron_ob.get_next(float)
        # utils.log('new run time' +  str(new_run_time))
        # utils.log('next run time' + str(self.next_run))
        if(new_run_time != self.next_run):
            self.next_run = new_run_time
            utils.showNotification('EPG Updater', 'Next Update: ' + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))
            utils.log("scheduler will run again on " + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))




class UpdateMonitor(xbmc.Monitor):
    update_method = None

    def __init__(self,*args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.update_method = kwargs['update_method']

    def onSettingsChanged(self):
        self.update_method()

if __name__ == "__main__":
  epg_updater = epgUpdater()
  epg_updater.run()