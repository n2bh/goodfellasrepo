import xbmcplugin,xbmcaddon
import time
import datetime
import xbmc
import os
import urllib2,json
import zipfile
import lib.utils as utils
from lib.croniter import croniter
from collections import namedtuple
from shutil import copyfile
import traceback
jsonGetPVR = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"pvrmanager.enabled"}, "id":1}'
jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":%s},"id":1}'
jsonNotify = '{"jsonrpc":"2.0", "method":"GUI.ShowNotification", "params":{"title":"PVR", "message":"%s","image":""}, "id":1}'

__addon__ = xbmcaddon.Addon()
__author__ = __addon__.getAddonInfo('author')
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__ = __addon__.getAddonInfo('path')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString
debug = __addon__.getSetting("debug")
# offset1hr = __addon__.getSetting("offset1hr")

offset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
offset = offset / 60 / 60 * -1


class epgUpdater:
    def __init__(self):
        self.monitor = UpdateMonitor(update_method = self.settingsChanged)
        self.enabled = utils.getSetting("enable_scheduler")
        self.next_run = 0
        self.update_m3u = False
        self.enablePVR = utils.getSetting("enable_pvr")
        if self.enablePVR == 'true':
            self.enableAddons()
        self.addonNeedsRestart = False
        self.restartPVR = False

        updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.gfvip2')
        if not os.path.isdir(updater_path):
          try:
            os.mkdir(updater_path)
          except:
            pass

        try:
          self.VADER_addon = xbmcaddon.Addon('plugin.video.gfvip2')
          utils.setSetting("pluginmissing", "false")
        except:
          utils.log("Failed to find VADER addon")
          self.VADER_addon = None
          utils.setSetting("pluginmissing", "true")
        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None

    def enableAddons(self):
        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
        result = xbmc.executeJSONRPC(json)

        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
        result = xbmc.executeJSONRPC(json)

        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None


    def restartAddon(self):
        utils.log("restarting addon")

        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":false},"id":1}'
        result = xbmc.executeJSONRPC(json)
        xbmc.sleep(100)
        json = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
        result = xbmc.executeJSONRPC(json)

        try:
            self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
            utils.log("Failed to find pvr.iptvsimple addon")
            self.pvriptvsimple_addon = None

    def run(self):
        utils.log("StalkerSettings::scheduler enabled, finding next run time")
        install_adv_file = utils.getSetting("install_adv_file")
        if install_adv_file == 'true':
          self.installAdvSettings()
        # Update when starting
        self.updateGroups()
        self.updateM3u()
        if self.enabled:
          self.updateEpg()

        self.findNextRun(time.time())
        while(not xbmc.abortRequested):
            # Sleep/wait for abort for 10 seconds
            now = time.time()
            if(self.enabled):
              if(self.next_run <= now):
                  self.updateEpg()
                  self.findNextRun(now)
              else:
                  self.findNextRun(now)
              if(self.update_m3u):
                  self.updateM3u()
                  self.update_m3u = False
            xbmc.sleep(500)
        # del self.monitor

    def updateGroups(self):
      self.groups = []
      for group in [ "Live Sports", "Live Events", "UKTV HD", "USTV HD", "CANTV HD", "Sportsworld HD", "Premium Movies"]:
        if utils.getSetting(group) == 'true':
          self.groups.append(group)
      utils.log(str(self.groups))

    def installKeyboardFile(self):
      keyboard_file_path = os.path.join(xbmc.translatePath('special://home'), 'addons/plugin.video.gfvip2/keyboard.xml')
      if os.path.isfile(keyboard_file_path):
        utils.log("Keyboard file found.  Copying...")
        copyfile(keyboard_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'keymaps/keyboard.xml'))


    def installAdvSettings(self):
        adv_file_path = os.path.join(xbmc.translatePath('special://home'),
                                          'addons/plugin.video.gfvip2/advancedsettings.xml')
        if os.path.isfile(adv_file_path):
            utils.log("Advanced Settings file found.  Copying...")
            copyfile(adv_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'advancedsettings.xml'))

    def settingsChanged(self):
        utils.log("Settings changed - update")
        old_settings = utils.refreshAddon()
        current_enabled = utils.getSetting("enable_scheduler")
        install_keyboard_file = utils.getSetting("install_keyboard_file")
        if install_keyboard_file == 'true':
          self.installKeyboardFile()
          utils.setSetting('install_keyboard_file', 'false')
          # Return since this is going to be run immediately again
          return

        install_adv_file = utils.getSetting("install_adv_file")
        if install_adv_file == 'true':
          self.installAdvSettings()
          utils.setSetting('install_adv_file', 'false')
          # Return since this is going to be run immediately again
          return


        # Update m3u file if wanted groups has changed
        old_groups = self.groups
        self.updateGroups()
        if self.groups != old_groups or old_settings.getSetting("username") != utils.getSetting("username") or old_settings.getSetting("password") != utils.getSetting("password") or old_settings.getSetting("mergem3u_fn") != utils.getSetting("merge3mu_fn") or old_settings.getSetting("mergem3u") != utils.getSetting("mergem3u"):
          self.addonNeedsRestart = True
          self.restartPVR = True
          self.updateM3u()
          self.updateEpg()

        utils.log('Flagging setting pvr :: ' + utils.getSetting("enable_pvr"))
        utils.log('Flagging old setting pvr :: ' + old_settings.getSetting('enable_pvr'))

        if utils.getSetting("enable_pvr") == 'true' and old_settings.getSetting('enable_pvr') == 'false':
            utils.log('Flagging pvr to restart')
            self.addonNeedsRestart = True
            self.restartPVR = True
            self.updateM3u()
            self.updateEpg()


        # if old_settings.getSetting("timezone") != utils.getSetting("timezone"):
        #   if self.pvriptvsimple_addon:
        #     utils.log("Changing offset")
        #     self.checkAndUpdatePVRIPTVSetting("epgTimeShift", utils.getSetting("timezone"))

        if(self.enabled == "true"):
            #always recheck the next run time after an update
            utils.log('recalculate start time , after settings update')
            self.findNextRun(time.time())

    def parseSchedule(self):
        schedule_type = int(utils.getSetting("schedule_interval"))
        cron_exp = utils.getSetting("cron_schedule")

        hour_of_day = utils.getSetting("schedule_time")
        hour_of_day = int(hour_of_day[0:2])
        if(schedule_type == 0 or schedule_type == 1):
            #every day
            cron_exp = "0 " + str(hour_of_day) + " * * *"
        elif(schedule_type == 2):
            #once a week
            day_of_week = utils.getSetting("day_of_week")
            cron_exp = "0 " + str(hour_of_day) + " * * " + day_of_week
        elif(schedule_type == 3):
            #first day of month
            cron_exp = "0 " + str(hour_of_day) + " 1 * *"

        return cron_exp


    def findNextRun(self,now):
        #find the cron expression and get the next run time
        cron_exp = self.parseSchedule()
        cron_ob = croniter(cron_exp,datetime.datetime.fromtimestamp(now))
        new_run_time = cron_ob.get_next(float)
        # utils.log('new run time' +  str(new_run_time))
        # utils.log('next run time' + str(self.next_run))
        if(new_run_time != self.next_run):
            self.next_run = new_run_time
            utils.showNotification('EPG Updater', 'Next Update: ' + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))
            utils.log("scheduler will run again on " + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))


    def updateM3u(self):

        enablePVR = utils.getSetting('enable_pvr')
        username = utils.getSetting('username')
        password = utils.getSetting('password')
        updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.gfvip2')

        if self.pvriptvsimple_addon is None:
            self.restartAddon()
            if self.pvriptvsimple_addon is None:
                utils.log("pvriptvsimple addon missing")
                return

        utils.log("updateM3u: " + enablePVR )

        if enablePVR == 'true':




            self.checkAndUpdatePVRIPTVSetting("epgCache", "false")
            self.checkAndUpdatePVRIPTVSetting("epgPathType", "0")
            self.checkAndUpdatePVRIPTVSetting("epgPath", updater_path + '/VADER_xmltv.xml.gz')
            self.checkAndUpdatePVRIPTVSetting("m3uPathType", "0")
            self.checkAndUpdatePVRIPTVSetting ('epgTimeShift', str(offset) )
            self.checkAndUpdatePVRIPTVSetting('logoFromEpg', '2' )

            self.checkAndUpdatePVRIPTVSetting("m3uPath", "{0}/VADER.m3u".format(updater_path))


            utils.log("Updating m3u file")
            if self.addonNeedsRestart == True:
                self.restartAddon()
                self.addonNeedsRestart = False
                utils.log("restarting pvr")
                if self.restartPVR == True:
                    xbmc.sleep(500)
                    PVR = json.loads(xbmc.executeJSONRPC(jsonGetPVR))['result']['value']
                    xbmc.executeJSONRPC(jsonSetPVR % "true")
                    xbmc.executeJSONRPC(jsonNotify % "Live TV Enabled, Restart Kodi")
                    utils.log("restarting pvr complete")
                    self.restartPVR = False


        cm_path = os.path.join(xbmc.translatePath('special://home'), 'addons/plugin.video.gfvip2/channel_guide_map.txt')

        channel_map = {}
        if os.path.isfile(cm_path):
          utils.log('Adding mapped guide ids')
          with open(cm_path) as f:
            for line in f:
              channel_name,guide_id = line.rstrip().split("\t")
              channel_map[channel_name] = guide_id

        panel_url = "http://vaders.tv/panel_api.php?username={0}&password={1}".format(username, password)
        try:
            u = urllib2.urlopen(panel_url)
            j = json.loads(u.read())


            if j['user_info']['auth'] == 0:
              utils.showNotification("EPG Updater", "Error: Couldn't login to Goodfellas")
              self.enabled = False
              utils.setSetting("enable_scheduler", "False")
              return

        except Exception as e:
            self.enabled = False
            utils.showNotification("EPG Updater", "Error: Couldn't login to Goodfellas")
            utils.log("Error creating m3u file\n{0}\n{1}".format(e,traceback.format_exc()))
            return

        Channel = namedtuple('Channel', ['tvg_id', 'tvg_name', 'tvg_logo', 'group_title', 'channel_url'])
        channels = []

        group_idx = {}
        for idx,group in enumerate(self.groups):
          group_idx[group] = idx

        for ts_id, info in j["available_channels"].iteritems():
            channel_url = "http://vaders.tv/live/{0}/{1}/{2}.ts".format(username, password, ts_id)
            tvg_id = ""
            tvg_name = info['name']
            #if info['epg_channel_id'] and info['epg_channel_id'].endswith(".com"):
            #    tvg_id = info['epg_channel_id']
            if tvg_name in channel_map:
                tvg_id = 'tvg-id="{0}"'.format(channel_map[tvg_name])
            else:
                tvg_id = ""
            tvg_id = ""
            tvg_logo = ""
            group_title = info['category_name']
            if group_title == None:
                group_title = 'None'
            channels.append(Channel(tvg_id, tvg_name, tvg_logo, group_title, channel_url))

        wanted_channels = [c for c in channels if c.group_title in self.groups]
        wanted_channels.sort(key=lambda c: "{0}-{1}".format(group_idx[c.group_title], c.tvg_name))

        try:
          with open("{0}/VADER.m3u".format(updater_path), "w") as m3u_f:
              m3u_f.write("#EXTM3U\n")
              for c in wanted_channels:
                  m3u_f.write('#EXTINF:-1 tvg-name="{0}" {1} tvg-logo="{2}" group-title="{3}",{0}\n{4}\n'.format(c.tvg_name, c.tvg_id, c.tvg_logo, c.group_title, c.channel_url))
              if utils.getSetting("mergem3u") == "true":
                mergem3u_fn = utils.getSetting("mergem3u_fn")
                if os.path.isfile(mergem3u_fn):
                  with open(mergem3u_fn) as mergem3u_f:
                    for line in mergem3u_f:
                      if line.startswith("#EXTM3U"):
                        continue
                      m3u_f.write(line)
        except Exception as e:
          utils.log("Error creating m3u file\n{0}\n{1}".format(e,traceback.format_exc()))


    def checkAndUpdatePVRIPTVSetting(self, setting, value):
      if self.pvriptvsimple_addon.getSetting(setting) != value:
        self.pvriptvsimple_addon.setSetting(setting, value)
        self.addonNeedsRestart = True

    def updateEpg(self):
        epgFileName = 'p2.xml.gz'
        epgFile = None
        if self.VADER_addon is None:
            updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.gfvip2')
        else:
            updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.gfvip2')
        iptvsimple_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/pvr.iptvsimple')
        if not os.path.exists(iptvsimple_path):
            os.makedirs(iptvsimple_path)

        try:
            response = urllib2.urlopen('https://github.com/psyc0n/epgninja/raw/subs/'+epgFileName)
            epgFile = response.read()
        except Exception as e:
            utils.log('StalkerSettings: Some issue with epg file')
            utils.log('{0}\n{1}'.format(e, traceback.format_exc()))

        if epgFile is None:
          try:
              response = urllib2.urlopen('http://162.253.251.2/'+epgFileName)
              epgFile = response.read()
          except Exception as e:
              utils.log('StalkerSettings: Guide backup download failed.')
              utils.log('{0}\n{1}'.format(e, traceback.format_exc()))
              return

        if epgFile:
            epgFH = open(updater_path + '/VADER_xmltv.xml.gz', "wb")
            epgFH.write(epgFile)
            epgFH.close()

        genresFile = None
        try:
            response = urllib2.urlopen('https://github.com/psyc0n/epgninja/raw/subs/genres.xml')
            genresFile = response.read()
        except Exception as e:
            utils.log('StalkerSettings: Some issue with genres file')
            utils.log('{0}\n{1}'.format(e, traceback.format_exc()))

        if genresFile is None:
          try:
              response = urllib2.urlopen('http://162.253.251.2/genres.xml')
              genresFile = response.read()
          except Exception as e:
              utils.log('StalkerSettings: Genres backup download failed.')
              utils.log('{0}\n{1}'.format(e, traceback.format_exc()))
              return

        if self.pvriptvsimple_addon:
            if genresFile:
                genresFH = open(iptvsimple_path + '/genres.xml', "w")
                genresFH.write(genresFile)
                genresFH.close()
            utils.log("Genres updated")

class UpdateMonitor(xbmc.Monitor):
    update_method = None

    def __init__(self,*args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.update_method = kwargs['update_method']

    def onSettingsChanged(self):
        self.update_method()

if __name__ == "__main__":
  epg_updater = epgUpdater()
  epg_updater.run()
