﻿import xbmcplugin, xbmcgui, xbmcaddon,  plugintools
import time
from lib import routing
from lib import  vader
from xbmcplugin import addDirectoryItem, endOfDirectory
from xbmcgui import ListItem
import xbmc
from unidecode import unidecode


firstrun = plugintools.get_setting('first')



plugin = routing.Plugin()

@plugin.route('/')
def index():
    if vaderClass.authorise():
        if vaderClass.show_categories:
            addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_cat, 'all'), ListItem("Live TV"), True)
        else:
            addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_all), ListItem("Live TV"), True)

        addDirectoryItem(plugin.handle, plugin.url_for(tvguide), ListItem("TV Guide"), True)
        addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_cat, '26'), ListItem("Live Sports"), True)
        addDirectoryItem(plugin.handle, plugin.url_for(show_mc), ListItem("MatchCenter"), True)
        addDirectoryItem(plugin.handle, plugin.url_for(settings), ListItem("Settings"), True)

        endOfDirectory(plugin.handle)
    else:
        addDirectoryItem(plugin.handle, plugin.url_for(settings), ListItem("Invalid Login - Click here to configure"), True)
        endOfDirectory(plugin.handle)


@plugin.route('/livetv/category/<category_id>')
def show_livetv_cat(category_id):
    if category_id == 'all':
        categories = vaderClass.get_categories()
        for category in categories:
            for cat_id in category:
                addDirectoryItem(plugin.handle, plugin.url_for(show_livetv_cat, category_id=str(cat_id)), ListItem(category[cat_id]), True)
        endOfDirectory(plugin.handle)
    else:
        streams = vaderClass.get_category_id_live(category_id)
        for stream in streams:
            chanName = streams[stream]['name']
            stream = streams[stream]['stream_id']
            icon = streams[stream]['stream_icon']
            chanUrl =  vaderClass.build_stream_url(stream)

            if vaderClass.get_epg_chan(chanName):
                title = '[COLOR orange]' +  chanName + '[/COLOR] - ' + '[I][COLOR cyan]' + vaderClass.get_epg_chan(chanName) +'[/COLOR][/I]'
            else:
                title = chanName

            title = str(title.encode('utf-8').decode('ascii', 'ignore'))

            plugintools.add_playable(title=title, url=chanUrl,
                                     thumbnail=icon, plot='',  isPlayable=True, folder=False)

        endOfDirectory(plugin.handle)



@plugin.route('/livetv/all/')
def show_livetv_all():
    streams = vaderClass.get_all_streams()
    for stream in streams:
        chanName = streams[stream]['name']
        stream = streams[stream]['stream_id']
        icon = streams[stream]['stream_icon']
        chanUrl = vaderClass.build_stream_url(stream)
        category_id = int(streams[stream]['category_id'])
        if category_id not in vaderClass.filter_category_list_id:
            if vaderClass.get_epg_chan(chanName):
                title = '[COLOR orange]' +  chanName + '[/COLOR] - ' + '[I][COLOR cyan]' + vaderClass.get_epg_chan(chanName) +'[/COLOR][/I]'
            else:
                title = chanName

            title = str(title.encode('utf-8').decode('ascii', 'ignore'))
            plugintools.add_playable(title=title, url=chanUrl,
                                     thumbnail=icon, plot='', isPlayable=True, folder=False)

    endOfDirectory(plugin.handle)


@plugin.route('/mc/')
def show_mc():
    closedTime = plugintools.get_setting('mcClosedTime')
    if closedTime == None or closedTime == '':
        plugintools.set_setting('mcClosedTime', '0')
    closedTime = int((plugintools.get_setting('mcClosedTime')))
    timeDiff = time.time() - closedTime
    if time.time() - closedTime > 3:
        endOfDirectory(plugin.handle)
        vaderClass.mcc.run()
    else:
        index()


@plugin.route('/tvguide')
def tvguide():
    xbmc.executebuiltin("XBMC.ActivateWindow(tvguide)")


@plugin.route('/settings')
def settings():
    plugintools.open_settings_dialog()

if __name__ == '__main__':
    vaderClass = vader.vader(plugin)
    plugin.run()
