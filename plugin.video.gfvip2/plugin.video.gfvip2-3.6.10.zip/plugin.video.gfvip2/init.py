﻿import urllib, urllib2, sys, re, xbmcplugin, xbmcgui, xbmcaddon, os, json, base64, plugintools
import xml.etree.ElementTree as ElementTree, traceback
import time
import traceback
from datetime import datetime
import calendar


reload(sys)
sys.setdefaultencoding('utf-8')
SKIN_VIEW_FOR_MOVIES = "515"
addonDir = plugintools.get_runtime_path()
global kontroll
background = "background.png"
defaultlogo = "defaultlogo.png"
hometheater = "hometheater.jpg"
noposter = "noposter.jpg"
theater = "theater.jpg"
addonxml = "addon.xml"
addonpy = "default.py"
icon = "icon.png"
fanart = "fanart.png"
firstrun = plugintools.get_setting('first')


# Entry point
def run():
    global pnimi
    global televisioonilink
    global filmilink
    global andmelink
    global uuenduslink
    global lehekylg
    global LOAD_LIVE
    global uuendused
    global vanemalukk
    global rssfeedurl
    global myschedurl
    global version
    global addonDir
    if firstrun == 'yes':
        intro = addonDir + '/resources/vader.mp4'
        xbmc.executebuiltin("PlayMedia(%s)" % (intro))
        plugintools.set_setting('first', 'no')
    version = int(get_live("2"))
    kasutajanimi = plugintools.get_setting(get_live("username"))
    salasona = plugintools.get_setting(vod_channels("password"))
    lehekylg = sync_data("http://vaders.tv")
    pordinumber = sync_data("80")
    uuendused = plugintools.get_setting(sync_data("uuendused"))
    vanemalukk = plugintools.get_setting(sync_data("vanemalukk"))
    pnimi = get_live("GoodFellas")
    LOAD_LIVE = os.path.join(plugintools.get_runtime_path(), get_live("resources"), vod_channels("art"))
    plugintools.log(pnimi + get_live("Starting up"))
    televisioonilink = "%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories" % (
    lehekylg, pordinumber, kasutajanimi, salasona)
    filmilink = vod_channels("%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories") % (
    lehekylg, pordinumber, kasutajanimi, salasona)
    andmelink = vod_channels("%s:%s/panel_api.php?username=%s&password=%s") % (
    lehekylg, pordinumber, kasutajanimi, salasona)
    uuenduslink = get_live("https://www.dropbox.com/s/a23q0as5pasvn8s/VaderVersion.txt?dl=1")
    rssfeedurl = get_live("https://twitrss.me/twitter_user_to_rss/?user=VadersStreams")
    myschedurl = get_live("http://axxess.tv/schedule_new/index.php")

    # Get params
    params = plugintools.get_params()

    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action + "(params)"

    plugintools.close_item_list()


# Main menu
def main_list(params):
    plugintools.log(pnimi + vod_channels("Main Menu") + repr(params))
    # load_channels()
    if not lehekylg:
        plugintools.open_settings_dialog()
    if uuendused == "true":
        kontrolli_uuendusi()
    channels = kontroll()
    if channels == 1:
        plugintools.log(pnimi + vod_channels("Login Success"))


        plugintools.add_item(action=vod_channels("getGuide"), title="[COLOR red]TV Guide[/COLOR]",
                             thumbnail="https://archive.org/download/MYAccount_201608/TV%20Guide.png",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=False)
        plugintools.add_item(action=vod_channels("execute_ainfo"),
                             title=vod_channels("[COLOR red] My Account [/COLOR]"),
                             thumbnail="https://archive.org/download/MYAccount_201608/MY%20Account.png",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=True)
        plugintools.add_item(action="getMatchCenter&category=all", title="[COLOR orange]MatchCenter[/COLOR]",
                             thumbnail="https://archive.org/download/MYAccount_201608/MY%20Schedule.png",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=True)
        plugintools.add_item(action="getLiveSports", title="[COLOR orange]Live Channels [/COLOR]",
                             thumbnail="https://archive.org/download/MYAccount_201608/Live%20Channels.png",
                             fanart=os.path.join(LOAD_LIVE, "background.png"), folder=True)
        plugintools.add_item(action="getLiveTV", title=vod_channels("[COLOR red]Live TV [/COLOR]"),
                             thumbnail="https://archive.org/download/MYAccount_201608/LIVE%20TV.png",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=True)

        plugintools.add_item(action="license_check", title=vod_channels("[COLOR red]Settings[/COLOR]"),
                             thumbnail="https://archive.org/download/MYAccount_201608/SETTINGS.png",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=False),
        plugintools.add_item(action="", title="[COLOR red]**Server Status** [/COLOR]",
                             thumbnail="https://archive.org/download/MYAccount_201608/SERVER%20STATUS.png",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=False)
        plugintools.add_item(action="", title="", thumbnail="",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=False)
        plugintools.add_item(action='', title="Please Follow us on Twitter: https://twitter.com/GoodfellasTeam",
                             thumbnail="", fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=False)
        plugintools.add_item(action="", title="Please join us on Facebook: http://bit.do/GoodfellasGroup", thumbnail="",
                             fanart=os.path.join(LOAD_LIVE, vod_channels("background.png")), folder=False)
        plugintools.set_view(plugintools.LIST)
    else:
        plugintools.log(pnimi + vod_channels("Login failed"))
        plugintools.message("Login failed", "[COLOR gold]Please Contact us on FaceBook![/COLOR]")
        exit(0)
    if plugintools.get_setting("improve") == "true":
        tseaded = xbmc.translatePath(sync_data("special://userdata/advancedsettings.xml"))
        if not os.path.exists(tseaded):
            file = open(os.path.join(plugintools.get_runtime_path(), vod_channels("resources"),
                                     sync_data("advancedsettings.xml")))
            data = file.read()
            file.close()
            file = open(tseaded, "w")
            file.write(data)
            file.close()
            plugintools.message(pnimi, get_live("New advanced streaming settings added."))


# Settings dialog
def exit(params):
    plugintools.set_setting('first', 'yes')
    xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
    xbmc.executebuiltin("XBMC.ActivateWindow(Home)")


def license_check(params):
    plugintools.log(pnimi + get_live("Settings menu") + repr(params))
    plugintools.open_settings_dialog()



def listCategories(params):
    cats = ['Hockey', 'Baseball', 'Basketball', 'World Football',  'General TV', 'Tennis', 'Motor Sports', 'Other Sports', 'Rugby', 'Golf', 'NFL', 'Cricket', 'Ice Hockey', 'NBA', 'Boxing', 'Wresling', 'Formula 1', 'NCAAF']
    cats.sort()

    plugintools.add_item(action='getMatchCenter&category=all', title="Category: " + 'All', folder=True)

    for category in cats:

        plugintools.add_item(action='getMatchCenter&category='+category, title="Category: " + category, folder=True)


def getGuide(params):
    xbmc.executebuiltin("XBMC.ActivateWindow(tvguide)")


def getMatchCenter(params):
    plugintools.log('CATEGORY:::::' + str(params))
    try:
        category = params['category'].title()
    except:
        plugintools.log(traceback.format_exc())
        category = 'all'

    plugintools.add_item(action='listCategories', title="Category: " + category, folder=True)

    username = plugintools.get_setting("username")
    password = plugintools.get_setting("password")
    manualOffsetEnabled = plugintools.get_setting("mc_timezone_enable")
    mcBackward = float(plugintools.get_setting("mc_backward"))*60*60*-1
    mcForward = float(plugintools.get_setting("mc_forward"))*60*60


    plugintools.log(pnimi + sync_data("Live Menu") + repr(params))

    u = urllib2.urlopen('http://vaders.tv/getMatchCenter').read()
    # u = urllib2.urlopen('http://localhost:8888/getMatchCenter').read()

    data = json.loads(u.decode('utf-8'))


    if manualOffsetEnabled == 'false' :
        is_dst = time.daylight and time.localtime().tm_isdst > 0
        offset = - (time.altzone if is_dst else time.timezone)

    else:
        offset = float(plugintools.get_setting('mc_timezone'))
        offset = offset*60*60



    ddd = time.time()
    dt = datetime.utcnow()
    # timeNow = dt.strftime("%S")
    # timeNow = int(timeNow)

    timeNow = time.mktime(dt.timetuple())



    validItems = []
    dataSorted = sorted(data, key=lambda k: k['startTime'])

    for epgItem in dataSorted:
        name = epgItem['name'].encode('utf-8')
        startTime = epgItem['startTime']
        endTime = epgItem['endTime']
        stream = epgItem['stream']

        if int(endTime) > timeNow and int(startTime) < timeNow  :
            validItems.append(epgItem)


        if int(startTime) - timeNow < 0 and int(startTime) - timeNow > mcBackward:
            validItems.append(epgItem)

        if int(startTime) - timeNow > 0 and int(startTime) - timeNow < mcForward:
            validItems.append(epgItem)

    sortedEpg = sorted(validItems, key=lambda k: k['startTime'])

    for epgItem in sortedEpg:
        startTime = epgItem['startTime'] + (offset)
        quality = epgItem['quality']
        itemCategory = epgItem['category']
        if category.lower() in itemCategory.lower() or category.lower() in 'all':
            startTimeString = datetime.fromtimestamp(int(startTime)).strftime("%d - %H:%M")

            title = '[COLOR red]' + startTimeString + '[/COLOR] ' + '[COLOR yellow]' + itemCategory + '[/COLOR] ' + '[COLOR green] ' + quality + '[/COLOR] ' + epgItem['name']
            chanUrl = 'http://vaders.tv/live/%s/%s/%s.%s' % (username, password, epgItem['stream'], 'ts')

            plugintools.add_playable(title=title, url=chanUrl, thumbnail='',
                                 plot='', fanart='',
                                 extra="", isPlayable=True, folder=False)


        plugintools.set_view(plugintools.EPISODES)





# Live TV

# Live Sports

def getLiveEvents(params):
    plugintools.log(pnimi + sync_data("Live Menu") + repr(params))
    catMap = {}
    request = urllib2.Request(televisioonilink, headers={"Accept": "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("channel")):
        kanalinimi = channel.find(get_live("title")).text
        kanalinimi = base64.b64decode(kanalinimi)
        if kanalinimi == 'Live Events':
            kategoorialink = channel.find(vod_channels("playlist_url")).text
            catMap[kanalinimi] = kategoorialink
            getChans(kategoorialink, 'Live Events')

    plugintools.set_view(plugintools.LIST)


# Live Sports

def getLiveSports(params):
    plugintools.log(pnimi + sync_data("Live Menu") + repr(params))
    catMap = {}
    request = urllib2.Request(televisioonilink, headers={"Accept": "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("channel")):
        kanalinimi = channel.find(get_live("title")).text
        kanalinimi = base64.b64decode(kanalinimi)
        if kanalinimi == 'Live Sports':
            kategoorialink = channel.find(vod_channels("playlist_url")).text
            catMap[kanalinimi] = kategoorialink
            getChans(kategoorialink, 'Live Sports')
    plugintools.set_view(plugintools.LIST)


# Live TV
def getLiveTV(params):
    plugintools.log(pnimi + sync_data("Live Menu") + repr(params))
    iterateOrder = ['UKTV', 'Premium', 'USTV', 'CANTV', 'Sportsworld', 'HINDI', 'URDU', 'Live Sports']
    catMap = {}
    request = urllib2.Request(televisioonilink, headers={"Accept": "application/xml"})
    plugintools.log(televisioonilink)
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("channel")):
        kanalinimi = channel.find(get_live("title")).text
        kanalinimi = base64.b64decode(kanalinimi)
        if kanalinimi != 'Live Events' and kanalinimi != 'All' and kanalinimi != 'Live Sports':
            kategoorialink = channel.find(vod_channels("playlist_url")).text
            catMap[kanalinimi] = kategoorialink
            plugintools.log(kategoorialink)

    plugintools.set_view(plugintools.LIST)
    plugintools.log(str(catMap))
    for categoryOrder in iterateOrder:
        for categoryKey in catMap:
            if categoryOrder in categoryKey:
                getChans(catMap[categoryKey], categoryKey)


# VOD
def detect_modification(params):
    plugintools.log(pnimi + vod_channels("VOD Menu ") + repr(params))
    request = urllib2.Request(filmilink, headers={"Accept": "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("channel")):
        filminimi = channel.find(get_live("title")).text
        filminimi = base64.b64decode(filminimi)

        kategoorialink = channel.find(vod_channels("playlist_url")).text
        plugintools.log(str(kategoorialink))
    # plugintools.add_item( action=vod_channels("get_myaccount"), title=filminimi , url=kategoorialink , thumbnail = "" , fanart=os.path.join(LOAD_LIVE,sync_data("noposter.jpg")) , folder=True )
    plugintools.set_view(plugintools.LIST)


# live channels

def stream_video(params):
    plugintools.log(pnimi + sync_data("Live Channels Menu ") + repr(params))
    if vanemalukk == "true":
        pealkiri = params.get(sync_data("title"))
        vanema_lukk(pealkiri)
    url = params.get(get_live("url"))
    request = urllib2.Request(url, headers={"Accept": "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall("channel"):
        kanalinimi = channel.find(get_live("title")).text
        kanalinimi = base64.b64decode(kanalinimi)
        kanalinimi = kanalinimi.partition("[")
        striimilink = channel.find(get_live("stream_url")).text
        pilt = channel.find(vod_channels("desc_image")).text

        kava = kanalinimi[1] + kanalinimi[2]
        kava = kava.partition("]")
        kava = kava[2]
        kava = kava.partition("   ")
        kava = kava[2]
        shou = get_live("[COLOR white]%s [/COLOR]") % (kanalinimi[0]) + kava
        kirjeldus = channel.find("description").text
        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)
            plugintools.log(str(kirjeldus))

            # kirjeldus = kirjeldus
            nyyd = kirjeldus.partition("(")
            nyyd = sync_data("NOW: ") + nyyd[0]
            jargmine = kirjeldus.partition(")\n")
            jargmine = jargmine[2].partition("(")
            jargmine = sync_data("NEXT: ") + jargmine[0]
            kokku = nyyd + jargmine
        else:
            kokku = ""
        if pilt:
            plugintools.add_playable(title=shou, url=striimilink, thumbnail=pilt,
                                 plot=kokku, fanart=os.path.join(LOAD_LIVE, vod_channels("hometheater.jpg")), extra="",
                                 isPlayable=True, folder=False)
        else:
            plugintools.add_playable(title=shou, url=striimilink,
                                 thumbnail=os.path.join(LOAD_LIVE, sync_data("defaultlogo.png")), plot=kokku,
                                 fanart=os.path.join(LOAD_LIVE, sync_data("hometheater.jpg")), extra="",
                                 isPlayable=True, folder=False)
    plugintools.set_view(plugintools.LIST)
    xbmc.executebuiltin(vod_channels("Container.SetViewMode(503)"))


def getChans(url, category):
    request = urllib2.Request(url, headers={"Accept": "application/xml"})

    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)

    rootElem = tree.getroot()

    try:
        for channel in tree.findall("channel"):

            kanalinimi = channel.find(get_live("title")).text
            kanalinimi = base64.b64decode(kanalinimi)
            kanalinimi = kanalinimi.partition("[")
            striimilink = channel.find(get_live("stream_url")).text
            pilt = channel.find(vod_channels("desc_image")).text

            kava = kanalinimi[1] + kanalinimi[2]
            kava = kava.partition("]")
            kava = kava[2]
            kava = kava.partition("   ")
            kava = kava[2]
            # shou = get_live("[COLOR red]%s [/COLOR][COLOR white]%s [/COLOR] [COLOR green]%s [/COLOR]")%(category ,  (kanalinimi[0]), kava )
            shou = get_live("[COLOR red]%s [/COLOR][COLOR orange]%s [/COLOR][I][COLOR cyan]%s[/COLOR][/I]") % (
            category, kanalinimi[0].replace('HD', '[COLOR green] HD [COLOR/]'), kava)

            # kirjeldus = channel.find("description").text
            kirjeldus = ''

            if kirjeldus:
                kirjeldus = base64.b64decode(kirjeldus)
                plugintools.log(str(kirjeldus))

                # kirjeldus = kirjeldus
                nyyd = kirjeldus.partition("(")
                nyyd = sync_data("NOW: ") + nyyd[0]
                jargmine = kirjeldus.partition(")\n")
                jargmine = jargmine[2].partition("(")
                jargmine = sync_data("NEXT: ") + jargmine[0]
                kokku = nyyd + jargmine
            else:
                kokku = ""
            if pilt:
                plugintools.add_playable(title=shou, url=striimilink, thumbnail=pilt,
                                     plot=kokku, fanart='',
                                     extra="", isPlayable=True, folder=False)
            else:
                plugintools.add_playable(title=shou, url=striimilink,
                                     thumbnail=os.path.join(LOAD_LIVE, sync_data("defaultlogo.png")), plot=kokku,
                                     fanart='', extra="",
                                     isPlayable=True, folder=False)
        plugintools.set_view(plugintools.LIST)
        xbmc.executebuiltin(vod_channels("Container.SetViewMode(502)"))
    except Exception:
        print(traceback.format_exc())


# vod listing
def get_myaccount(params):
    plugintools.log(pnimi + get_live("VOD channels menu ") + repr(params))
    if vanemalukk == "true":
        pealkiri = params.get(sync_data("title"))
        vanema_lukk(pealkiri)
    purl = params.get(get_live("url"))
    request = urllib2.Request(purl, headers={"Accept": "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("channel")):
        pealkiri = channel.find(get_live("title")).text
        pealkiri = base64.b64decode(pealkiri)
        # pealkiri = pealkiri
        pealkiri = pealkiri.encode("utf-8")
        striimilink = channel.find(sync_data("stream_url")).text
        pilt = channel.find(sync_data("desc_image")).text
        kirjeldus = channel.find(vod_channels("description")).text
        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)
        # kirjeldus = kirjeldus
        if pilt:
            plugintools.add_item(action="restart_service", title=pealkiri, url=striimilink, thumbnail=pilt,
                                 plot=kirjeldus, fanart=os.path.join(LOAD_LIVE, "theater.jpg"), extra="",
                                 isPlayable=True, folder=False)
        else:
            plugintools.add_item(action="restart_service", title=pealkiri, url=striimilink,
                                 thumbnail=os.path.join(LOAD_LIVE, "noposter.jpg"), plot=kirjeldus, fanart="", extra="",
                                 isPlayable=True, folder=False)
    plugintools.set_view(plugintools.MOVIES)
    xbmc.executebuiltin('Container.SetViewMode(515)')


def run_cronjob(params):
    plugintools.log(pnimi + sync_data("PLAY_LIVE") + repr(params))
    if vanemalukk == "true":
        pealkiri = params.get(sync_data("title"))
        vanema_lukk(pealkiri)
    lopplink = params.get(vod_channels("url"))
    plugintools.play_resolved_url(lopplink)


def sync_data(channel):
    video = channel
    return video


def restart_service(params):
    plugintools.log(pnimi + get_live("PLAY VOD") + repr(params))
    if vanemalukk == "true":
        pealkiri = params.get(sync_data("title"))
        vanema_lukk(pealkiri)
    lopplink = params.get(vod_channels("url"))
    plugintools.play_resolved_url(lopplink)


def grab_epg():
    req = urllib2.Request(andmelink)
    req.add_header(sync_data("User-Agent"), vod_channels("Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11"))
    response = urllib2.urlopen(req)
    link = response.read()
    if link:
        jdata = json.loads(link.decode('utf8'))
        if jdata['user_info']['auth'] == 1:
            plugintools.log('Updating user info....')
            username = jdata['user_info']['username']
            password = jdata['user_info']['password']
            plugintools.set_setting('username', username)
            plugintools.set_setting('password', password)

        response.close()
    else:
        plugintools.message(pnimi, "Please reconfigure plugin")
        plugintools.open_settings_dialog()
    if jdata:
        plugintools.log(pnimi + sync_data("jdata loaded "))
        return jdata


def kontroll():
    randomstring = grab_epg()
    kasutajainfo = randomstring[sync_data("user_info")]
    kontroll = kasutajainfo[get_live("auth")]
    return kontroll


def get_live(channel):
    video = channel
    return video


# My Account
def execute_ainfo(params):
    plugintools.log(pnimi + get_live("My account Menu ") + repr(params))
    andmed = grab_epg()
    kasutajaAndmed = andmed[sync_data("user_info")]
    seis = kasutajaAndmed[get_live("status")]
    aegub = kasutajaAndmed[sync_data("exp_date")]
    if aegub:
        aegub = datetime.fromtimestamp(int(aegub)).strftime('%H:%M %d.%m.%Y')
    else:
        aegub = vod_channels("Never")
    rabbits = kasutajaAndmed[vod_channels("is_trial")]
    if rabbits == "0":
        rabbits = sync_data("No")
    else:
        rabbits = sync_data("Yes")
    leavemealone = kasutajaAndmed[get_live("max_connections")]
    polarbears = kasutajaAndmed[sync_data("username")]
    plugintools.add_item(action="", title=sync_data("[COLOR = Orange]User: [/COLOR]") + polarbears, thumbnail="",
                         fanart=os.path.join(LOAD_LIVE, sync_data("background.png")), folder=False)
    plugintools.add_item(action="", title=sync_data("[COLOR = Orange]Status: [/COLOR]") + seis, thumbnail="",
                         fanart=os.path.join(LOAD_LIVE, sync_data("background.png")), folder=False)
    plugintools.add_item(action="", title=get_live("[COLOR = Orange]Expires: [/COLOR]") + aegub, thumbnail="",
                         fanart=os.path.join(LOAD_LIVE, sync_data("background.png")), folder=False)
    plugintools.add_item(action="", title=vod_channels("[COLOR = Orange]Trial account: [/COLOR]") + rabbits,
                         thumbnail="", fanart=os.path.join(LOAD_LIVE, sync_data("background.png")), folder=False)
    plugintools.add_item(action="", title=vod_channels("[COLOR = Orange]Max Devices: [/COLOR]") + leavemealone,
                         thumbnail="", fanart=os.path.join(LOAD_LIVE, sync_data("background.png")), folder=False)
    plugintools.set_view(plugintools.LIST)


def vanema_lukk(name):
    plugintools.log(pnimi + sync_data("Parental lock "))
    a = 'XXX', 'Adult', 'Adults', 'ADULT', 'ADULTS', 'adult', 'adults', 'Porn', 'PORN', 'porn', 'Porn', 'xxx'
    if any(s in name for s in a):
        xbmc.executebuiltin((u'XBMC.Notification("Parental Lock", "Channels may contain adult content", 2000)'))
        text = plugintools.keyboard_input(default_text="", title=get_live("Parental lock "))
        if text == plugintools.get_setting("vanemakood"):
            return
        else:
            exit()
    else:
        # xbmc.executebuiltin((u'XBMC.Notification("Parental Lock", "No adult content found", 2000)'))
        name = ""


def kontrolli_uuendusi():
    req = urllib2.Request(uuenduslink)
    req.add_header(vod_channels("User-Agent"), sync_data("Kodi plugin by MikkM"))
    response = urllib2.urlopen(req)
    repoversion = response.read()
    repoversion = repoversion.partition("\n")
    iversion = int(repoversion[0])
    global dlink
    dlink = repoversion[2]
    response.close()
    if iversion == version:
        update = " "
    else:
        if plugintools.message_yes_no(pnimi, sync_data("New update is available!"),
                                      get_live("Do you want to update plugin now?")):
            plugintools.log(pnimi + vod_channels("Trying to update plugin..."))
            try:
                destpathname = xbmc.translatePath(os.path.join(sync_data("special://"), sync_data("home/addons/")))
                local_file_name = os.path.join(plugintools.get_runtime_path(), get_live("update.zip"))
                plugintools.log(pnimi + local_file_name)
                urllib.urlretrieve(dlink, local_file_name)
                DownloaderClass(dlink, local_file_name)
                plugintools.log(pnimi + sync_data("Extracting update..."))
                import ziptools
                unzipper = ziptools.ziptools()
                # destpathname = xbmc.translatePath(os.path.join('special://','home'))
                plugintools.log(pnimi + destpathname)
                unzipper.extract(local_file_name, destpathname)
                os.remove(local_file_name)
                xbmc.executebuiltin((u'XBMC.Notification("Updated", "The add-on has been updated", 2000)'))
                # import updater
                xbmc.executebuiltin("Container.Refresh")
                plugintools.log(pnimi + get_live("Update success"))
            except:
                plugintools.log(pnimi + get_live("Update failed"))
                xbmc.executebuiltin((u'XBMC.Notification("Not updated", "An error causes the update to fail", 2000)'))


def DownloaderClass(url, dest):
    dp = xbmcgui.DialogProgress()
    dp.create(sync_data("Getting update"), get_live("Downloading"))
    urllib.urlretrieve(url, dest, lambda nb, bs, fs, url=url: _pbhook(nb, bs, fs, url, dp))



def _pbhook(numblocks, blocksize, filesize, url=None, dp=None):
    try:
        percent = min((numblocks * blocksize * 100) / filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        print "DOWNLOAD CANCELLED"  # need to get this part working
        dp.close()


def vod_channels(channel):
    video = channel
    return video


run()
