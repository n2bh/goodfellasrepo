import xbmcaddon

MainBase = 'http://bit.do/gf20x'
addon = xbmcaddon.Addon('plugin.video.goodfellas')